# UI/UX V15 review — 2026-10-27

Baseline: current main PRD V1.0 consolidated review draft, seven readable module specifications, and the 2026-10-26 independent metric catalog. This is not a frozen production specification.

The site includes the review at `?view=prd-review`, 20 main-PRD acceptance cases at `?view=acceptance`, and eight editable synthetic replay demos at `?view=demos`. Acceptance cases and evidence/report snapshots can be downloaded from their pages. Candidate metrics retain 45 platform definitions and 25 business configurations (14 reused, 11 additional; 56 independent candidates).

Key corrections: ordinary assets require distinct technical and business accounts; immutable version/hash confirmations; separate package and applicability-rule versions; no automatic migration of existing tasks; human-review pending takes precedence over quality failure for the overall verdict; valid failure counts toward coverage; weighted/latest-snapshot trends; budget reservation conversion is idempotent; unresolved cancellation requires querying and cleanup.

The demos cover PDF, pet service, RAG, summary, extraction, multi-agent, model/quantization/device evidence, and Factory generation versus child-agent business results. Their output fields can be changed. Scoring runs against the changed fields, not prewritten verdicts. Missing evidence and parser failures are distinct. No actual PDF parser, model, device, Factory, external endpoint, enterprise account authorization, or financial approval is connected.

Unread: the business/acceptance detail document and complete dictionary/interface document could not be reviewed in this session due document access limitations. Embedded figures and attachments were not fully reviewed. Consequently this release must not be described as full PRD acceptance or production readiness. Real business thresholds, statistical sample sizes, permissions, internal deployment boundaries, and true-device observations still require acceptance.

Verification: `node --test tests/*.test.cjs`. Main acceptance records are initially pending; local prototype tests never mark real business acceptance automatically. Browser observations will be recorded after deployment.

Browser verification on the deployed site: PDF abnormal output requires business confirmation before freeze; run completes with 4/5 effective coverage, pending review is INCONCLUSIVE and retains one confirmed failure; quality review appends BLOCK snapshot while preserving r1. Package draft publish creates package v2 while rules remain v1 and the existing frozen task retains package v1. Residual V14 header/footer labels were found and corrected.

Additional controller integration tests exercise all eight scenarios from draft through freeze, run, review, immutable snapshot, clone and successful corrected revision. Cancellation tests verify unresolved reservations, failed-reset quarantine and subsequent cleanup.

Responsive browser check: scene cards rendered at the five configured widths (320, 768, 820, 1024, 1440). At the narrowest width, asset center, metric catalog and permission pages kept the outer page within the viewport; tables scrolled locally. The responsive harness is available at `responsive.html`, with a native page and width selector. Screenshot review covered the narrow scene cards. Browser extension-origin errors were observed, but no site-origin JavaScript errors in the checked routes.
