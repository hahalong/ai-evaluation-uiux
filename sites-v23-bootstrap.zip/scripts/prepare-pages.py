"""Add static-host aliases without rewriting original source or historical evidence."""
from pathlib import Path

root = Path(__file__).resolve().parents[1] / "dist"
(root / ".nojekyll").touch()
# GitHub Pages serves directory indexes; preserve original extensionless walkthrough URLs.
alias = root / "walkthrough" / "index.html"
alias.parent.mkdir(exist_ok=True)
alias.write_text('''<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><title>场景走查</title>
<script>location.replace('../walkthrough.html'+location.search+location.hash);</script>
<p><a href="../walkthrough.html">进入场景走查</a></p></html>
''', encoding="utf-8")
print("GitHub Pages aliases prepared; query parameters and step anchors preserved.")
