from pathlib import Path
import json,shutil
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'dist/walkthrough-assets/manifest.json').read_text())
extra={x['id']:{**x['fixture'],'description':x['fixture'].get('description') or '验证'+x['title']+'的业务结果、证据完整性与失败分支（合成）','icon':x['fixture'].get('icon','file'),'color':x['fixture'].get('color','#3585c7')} for x in m['scenarios']}
(root/'dist/walkthrough-fixtures.js').write_text('(function(root,factory){if(typeof module===\'object\')module.exports=factory;else factory(root.PRD_FIXTURES);})(typeof globalThis===\'object\'?globalThis:this,function(base){Object.assign(base,'+json.dumps(extra,ensure_ascii=False)+');if(base.model)base.model.legacy=true;return base;});\n')
dest=Path('/workspace/scratch/c9376a4f25f2/walkthrough-20261028/uploads');shutil.copytree(root/'dist/walkthrough-assets',dest,dirs_exist_ok=True)
