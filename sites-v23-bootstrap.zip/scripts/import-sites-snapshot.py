"""One-time migration of the owner's public Sites V23 files, verified byte for byte.

Run only when importing the original snapshot. Normal Pages deploys use repository files.
"""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "migration/sites-v23-manifest.json").read_text())


def restore(item):
    path = ROOT / item["path"]
    if not item["path"].startswith("dist/") or ".." in Path(item["path"]).parts:
        raise ValueError("Invalid import path")
    if path.exists():
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise ValueError(f"Refusing to overwrite modified file: {item['path']}")
        return
    url = manifest["origin"] + "/" + urllib.parse.quote(item["path"][5:])
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=90) as response:
                data = response.read()
            if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError(f"Snapshot checksum mismatch: {item['path']}")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            return
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2 ** attempt)


if __name__ == "__main__":
    files = [item for item in manifest["files"] if item["path"].startswith("dist/")]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for count, _ in enumerate(pool.map(restore, files), 1):
            if count % 50 == 0:
                print(f"Verified {count}/{len(files)} files", flush=True)
    # Include non-web source/test/docs files in the same verification contract.
    for item in manifest["files"]:
        data = (ROOT / item["path"]).read_bytes()
        assert len(data) == item["bytes"], item["path"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]
    print(f"Verified all {len(manifest['files'])} original source files; no history regenerated.")
