#!/usr/bin/env python3
"""Encode truthful, captioned UI screenshot walkthroughs (not continuous recordings)."""
import argparse,json,shutil,subprocess,tempfile
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import fitz
p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];dest=root/'dist/walkthrough-current/media';dest.mkdir(exist_ok=True)
manifest=json.loads((root/'dist/walkthrough-assets/manifest.json').read_text());out=[]
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp);fontpath=tmp/'Chinese.ttf';fontpath.write_bytes(fitz.Font('china-s').buffer)
 title=ImageFont.truetype(str(fontpath),27);body=ImageFont.truetype(str(fontpath),22);small=ImageFont.truetype(str(fontpath),17)
 for scene in manifest['scenarios']:
  sid=scene['id'];logpath=a.evidence/f'{sid}-frames.json'
  if logpath.exists():frames=json.loads(logpath.read_text())
  else:
   # No inferred screenshot-to-action alignment; require a new capture manifest.
   continue
  available=[]
  for f in frames:
   src=a.evidence/f['file'] if f['file'].startswith('frame-') else a.evidence/'frames'/sid/f['file']
   if src.is_file() and src.stat().st_size:available.append((f,src))
  if not available:continue
  rawdest=dest/sid;rawdest.mkdir(exist_ok=True);work=tmp/sid;work.mkdir();entries=[]
  # Intro records the distinction between observed UI and real service acceptance.
  intro=Image.new('RGB',(1348,1056),'#142b46');d=ImageDraw.Draw(intro)
  for y,text,font,colour in [(220,scene['title'],title,'white'),(290,'正常评测自动收尾；报告按需导出、无需运维参与',body,'#d4e3f5'),(390,'实际页面截图合成的逐步演示 · 非连续录屏',body,'#f5d9a8'),(445,'合成数据与外部执行结果回放；没有真实模型或设备接通',body,'#d4e3f5'),(500,'完整操作、填写值、文件与外部准备：参见同场景 Demo 文档',body,'#d4e3f5')]:d.text((90,y),text,font=font,fill=colour)
  intro.save(work/'000.jpg',quality=92);entries.append((work/'000.jpg',5))
  for index,(f,src) in enumerate(available,1):
   raw=rawdest/f'{index:02}.jpg';shutil.copy2(src,raw)
   im=Image.open(src).convert('RGB');im.thumbnail((1348,926));canvas=Image.new('RGB',(1348,1056),'#142b46');canvas.paste(im,((1348-im.width)//2,0));d=ImageDraw.Draw(canvas)
   d.text((28,942),scene['title']+' | 操作 '+str(f['operation'])+' 附近页面：'+f['action'],font=body,fill='white')
   d.text((28,985),'实际页面截图合成 · 非连续录屏 | 合成验收，真实服务未验证',font=small,fill='#c3d4ea')
   d.text((28,1015),'逐项输入、上传文件及接入准备见场景文档；暂停视频可检查页面。',font=small,fill='#c3d4ea')
   file=work/f'{index:03}.jpg';canvas.save(file,quality=93);entries.append((file,5 if index==len(available) else 4))
  concat=work/'frames.txt';concat.write_text(''.join("file '"+str(f)+"'\nduration "+str(duration)+'\n' for f,duration in entries)+"file '"+str(entries[-1][0])+"'\n")
  target=dest/f'{sid}.mp4'
  subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(concat),'-vf','fps=12','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],check=True)
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size','-of','json',str(target)]))['format']
  subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','null','-'],check=True)
  item={'scene':sid,'type':'ACTUAL_UI_SCREENSHOT_SEQUENCE_NOT_CONTINUOUS_RECORDING','frames':len(available),'durationSeconds':float(probe['duration']),'bytes':int(probe['size']),'fullOperationLog':f'../walkthrough-docs/{sid}-operations.json','captionedOperations':[f['operation'] for f,_ in available]};out.append(item);(rawdest/'frames.json').write_text(json.dumps({'scene':sid,'frames':[f for f,_ in available]},ensure_ascii=False,indent=2));print(sid,len(available),probe['duration'],flush=True)
(dest/'manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
