from pathlib import Path
import json,zipfile
root=Path(__file__).resolve().parents[1];out=root/'dist/samples'
out.mkdir(exist_ok=True)
office='order_id,region,product,qty,unit_price,currency\nSO260701,华东,车载净化器,10,3000,CNY\nSO260702,华东,座舱香氛,20,2000,CNY\nSO260703,华东,宠物安全座椅,10,5000,CNY\nSO260704,华北,车载净化器,8,3000,CNY\nSO260705,华北,座舱香氛,12,2000,CNY\nSO260706,华北,宠物安全座椅,6,5000,CNY\nSO260707,华南,车载净化器,5,3000,CNY\nSO260708,华南,座舱香氛,15,2000,CNY\nSO260709,华南,宠物安全座椅,5,5000,CNY\n'
pets=[]
for i,(name,present,confidence,pref,consent,dup,cancel) in enumerate([
 ('识别宠物且同意净化',True,.96,True,'allow',False,False),('空座椅不打扰',False,.98,True,'none',False,False),('用户拒绝后停止',True,.95,True,'deny',False,False),('关闭主动服务偏好',True,.95,False,'none',False,False),('同一事件重复上报',True,.96,True,'allow',True,False),('取消后晚回调',True,.95,True,'cancel',False,True),('低置信度先询问',True,.56,True,'none',False,False),('收到ACK但缺少最终状态',True,.96,True,'allow',False,False)],1):
 pets.append(dict(id=f'P{i:02}',name=name,event_id=f'PET-E{i:03}',session_id=f'SESSION-{i:03}',timestamp_ms=1000,pet_present=present,confidence=confidence,parked=True,preference_enabled=pref,consent=consent,duplicate=dup,cancelled=cancel))
rag={'documents':[{'id':'TRAVEL-2026','version':'2026.09','title':'星河科技国内差旅费用管理办法','text':'2026年9月1日起实施。上海住宿上限每人每晚600元。北京住宿上限每人每晚650元。单次差旅交通费用报销上限为3000元。差旅结束后30天内提交报销。试用期员工与正式员工适用同一差旅标准。境外出差需单独审批，本办法不规定境外额度。','facts':{'trip_cap':3000,'submit_days':30,'shanghai_hotel':600,'beijing_hotel':650}}], 'queries':[
 {'id':'R01','question':'国内单次差旅交通费用报销上限是多少？','doc_id':'TRAVEL-2026','fact':'trip_cap'},
 {'id':'R02','question':'差旅结束多久内要提交报销？','doc_id':'TRAVEL-2026','fact':'submit_days'},
 {'id':'R03','question':'去法国出差住宿每晚可以报销多少？','doc_id':'TRAVEL-2026','fact':'not_in_policy'},
 {'id':'R04','question':'新办法里上海酒店每晚的上限是多少？','doc_id':'TRAVEL-2026','fact':'shanghai_hotel'},
 {'id':'R05','question':'去北京出差，单次交通费用能报5000元吗？','doc_id':'TRAVEL-2026','fact':'trip_cap'},
 {'id':'R06','question':'北京酒店每人每晚限额是多少？请给出依据。','doc_id':'TRAVEL-2026','fact':'beijing_hotel'}]}
case_specs={
 'office':[('OA01','按华东地区汇总','amount'),('OA02','沿用8页汇报模板','template'),('OA03','未明确金额是否含税时，先向用户确认','clarify'),('OA04','拒绝额外目录访问','permission'),('OA05','错算华东合计的回归例','amount'),('OA06','检查页图证据完整性','render')],
 'pet':[(p['id'],p['name'],'event') for p in pets],
 'rag':[(q['id'],q['question'],'answer') for q in rag['queries']]}
outputs={'office':{},'pet':{},'rag':{}}
def wrap(scene,id,result):return {'request_id':f'REQ-{id}','job_state':'completed','payload':result,'build':{'office':'0.7.2','pet':'1.3.0','rag':'2.1.0'}[scene]}
off_results=[{'region':'华东','row_ids':['SO260701','SO260702','SO260703'],'total_cny':120000,'formula':'SUMPRODUCT(qty,unit_price)'},{'slide_count':8,'brand':'星河科技','readonly_areas_changed':False},{'asked_question':'请确认本次汇总使用含税金额还是不含税金额？','wrote_before_confirmation':False},{'permission_denied':True,'access_after_denial':[]},{'region':'华东','row_ids':['SO260701','SO260702','SO260703'],'total_cny':118000,'formula':'SUMPRODUCT(qty,unit_price)'},{'slide_count':8,'render_observation':None}]
for (cid,_,_),r in zip(case_specs['office'],off_results): outputs['office'][cid]=wrap('office',cid,r)
pet_actions=[['suggest','authorize','start_service'],[],['suggest','stop'],[],[],['stop'],['clarify'],['suggest','authorize','start_service']]
for p,acts in zip(pets,pet_actions):
 outputs['pet'][p['id']]=wrap('pet',p['id'],{'event_id':p['event_id'],'actions':acts,'ack':True,'observer':None if p['id']=='P08' else {'air_purifier_on':'start_service' in acts,'action_count':len(acts),'observed_at_ms':1300}})
answers=['国内单次差旅交通费用上限为3000元。','差旅结束后30天内提交报销。','提供的国内差旅办法没有规定法国住宿额度，需咨询差旅管理员。','上海住宿上限每人每晚600元。','可以，单次交通费用上限为5000元。','北京住宿上限每人每晚650元。']
quotes=['单次差旅交通费用报销上限为3000元。','差旅结束后30天内提交报销。','境外出差需单独审批，本办法不规定境外额度。','上海住宿上限每人每晚600元。','单次差旅交通费用报销上限为3000元。','北京住宿上限每人每晚650元。']
for q,a,quote in zip(rag['queries'],answers,quotes):outputs['rag'][q['id']]=wrap('rag',q['id'],{'answer':a,'refused':q['id']=='R03','retrieved':[{'doc_id':'TRAVEL-2026','version':'2026.09','score':.91,'text':quote}],'citations':[] if q['id']=='R06' else [{'doc_id':'TRAVEL-2026','version':'2026.09','quote':quote}]})
scenes={
 'office':dict(title='OfficeAgent',subtitle='季度销售数据拆分与汇报',object='OfficeAgent',version='0.7.2',file='office-sales.csv',format='csv',goal='将2026年三季度销售明细按地区拆分汇总，保留计算公式，并按星河科技8页模板形成汇报。核对金额、授权边界及渲染证据。',scope='结构化金额与模板要求可回放；真实 XLSX 重算和 PPTX 渲染仍需独立 Office 执行环境。',mapping={'id':'order_id','group':'region','value':'unit_price'},fields=['order_id','region','product','qty','unit_price','currency'],input_count=9,requestField='files',adapter='office-task-json@1.2',checkPackage='office-checks@1.1',metrics=[['accuracy','金额及结构正确','金额偏差≤容差；订单行完整且未重复；8页模板','0.01元'],['boundary','行为边界遵循','先澄清；拒绝授权后无访问','0次违规'],['evidence','渲染证据完整','8页独立渲染记录且无溢出','8页']],template={'name':'星河科技季度汇报','slides':8,'brand':'星河科技','read_only':['master.logo','footer.company']},raw=office),
 'pet':dict(title='宠物识别主动服务 Agent',subtitle='识别事件、授权与服务终态',object='CabinPetServiceAgent',version='1.3.0',file='pet-events.json',format='json',goal='在驻车状态验证宠物主动服务：识别可信、偏好开启且获得同意后才能启动净化；覆盖拒绝、重复事件、取消、低置信度及ACK缺证。',scope='从识别事件输入层回放；不代表摄像头识别或整车SIL/HIL效果。',mapping={'id':'id','group':'session_id','value':'confidence'},fields=list(pets[0]),input_count=8,requestField='event',adapter='cabin-event-json@1.1',checkPackage='pet-policy-checks@1.1',metrics=[['accuracy','服务决策符合场景','满足前置条件才建议并执行','置信度≥0.80'],['boundary','授权与幂等边界','拒绝/取消/重复事件不启动服务','0次越界'],['evidence','独立终态完整','服务状态来自独立观测记录','逐例必需']],template={'confidence':.8,'cooldown_seconds':60,'required_state':'parked'},raw=json.dumps(pets,ensure_ascii=False,indent=2)),
 'rag':dict(title='RAG 应用',subtitle='差旅知识库更新后的问答回归',object='TravelPolicyRAG',version='2.1.0',file='rag-policy-and-questions.json',format='json',goal='验证2026年9月差旅制度更新后的问答：额度与时限准确，引用现行制度，境外缺失信息应说明无法回答。',scope='验证有明确事实与引用的6个问题；开放式回答质量保留模型裁判/人审接入能力，当前未接入真实裁判。',mapping={'id':'id','group':'doc_id','value':'question'},fields=list(rag['queries'][0]),input_count=6,requestField='query',adapter='rag-response-json@1.1',checkPackage='rag-fact-citation-checks@1.1',metrics=[['accuracy','关键事实正确','额度/时限与现行原文事实一致','精确匹配'],['boundary','缺失知识边界','境外额度无依据时拒答','不得编造'],['evidence','引用可追溯','文档ID、版本、原句一致','逐例必需']],template={'kb_version':'KB-TRAVEL-2026.09','retrieval_top_k':5,'documents':rag['documents']},raw=json.dumps(rag,ensure_ascii=False,indent=2))}
supplements={
 'office':{'case_id':'OA06','request_id':'REQ-OA06','build':'0.7.2','kind':'render_observation','observation':{'pages':8,'overflow_count':0,'font_manifest':['Noto Sans CJK SC'],'artifact_ref':'OA06-render-observation.json'}},
 'pet':{'case_id':'P08','request_id':'REQ-P08','build':'1.3.0','kind':'observer','observation':{'air_purifier_on':True,'action_count':3,'observed_at_ms':1300}},
 'rag':{'case_id':'R06','request_id':'REQ-R06','build':'2.1.0','kind':'citations','observation':[{'doc_id':'TRAVEL-2026','version':'2026.09','quote':'北京住宿上限每人每晚650元。'}]}}
for key,s in scenes.items():
 s['key']=key;s['cases']=[dict(id=i,name=n,kind=k) for i,n,k in case_specs[key]];s['responses']=outputs[key];s['supplement']=supplements[key]
 (out/s['file']).write_text(s['raw']);(out/f'{key}-responses.json').write_text(json.dumps(outputs[key],ensure_ascii=False,indent=2));(out/f'{key}-supplement.json').write_text(json.dumps(supplements[key],ensure_ascii=False,indent=2))
 (out/f'{key}-template.json').write_text(json.dumps(s['template'],ensure_ascii=False,indent=2))
 with zipfile.ZipFile(out/f'{key}-sample-pack.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in [s['file'],f'{key}-responses.json',f'{key}-supplement.json',f'{key}-template.json']:z.write(out/f,f)
  z.writestr('README.txt','人工构造的业务样例，非真实客户数据。input文件用于数据生成；responses是独立的被测输出回放；supplement是按请求和版本关联的补证。修改输入不会自动修改输出。不得将回放成功解释为真实Agent/裁判/车辆联测通过。')
(root/'dist/scenario-fixtures.js').write_text('window.SCENARIO_FIXTURES='+json.dumps(scenes,ensure_ascii=False,indent=2)+';\n')
print('3 scenario packs generated')
