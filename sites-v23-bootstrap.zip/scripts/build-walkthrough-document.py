#!/usr/bin/env python3
"""Publish current synthetic controller evidence without rewriting historical evidence.
Business completion is computed by shared runtime, never inferred from log count/export.
"""
from pathlib import Path
import datetime,html,json,hashlib,re
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'dist';C=D/'walkthrough-current';C.mkdir(exist_ok=True)
def read(p,default=None):
 try:return json.loads(p.read_text())
 except (OSError,json.JSONDecodeError):return default

def esc(x):return html.escape(str(x),quote=True)
def js(x):return json.dumps(x,ensure_ascii=False,indent=2)
def code(x):return '<pre><code>'+esc(x if isinstance(x,str) else js(x))+'</code></pre>'
def details(title,body,opened=False):return '<details'+(' open' if opened else '')+'><summary>'+esc(title)+'</summary><div class="detail-body">'+body+'</div></details>'
def table(headers,rows):return '<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def filelink(file,label):return '<a href="'+esc(file)+'" download>'+esc(label)+'</a>' if (D/file).is_file() else '<span class="missing">未生成：'+esc(label)+'</span>'
def pill(x):return '<span class="pill">'+esc(x)+'</span>'
labels={'role':'切换已分配演示账号','create-requirement':'新建需求与被测对象','load-demo':'明确载入合成场景','save-task':'保存需求与对象草稿','upload-input':'导入输入文件','upload-source':'登记原始事件 / 附件','upload-connection':'导入接入契约','data-ready':'确认输入、参考与统计口径','upload-output':'导入外部合成输出','pilot':'运行试评','preflight':'执行预检','business-confirm':'业务确认当前方案','freeze':'评测负责人冻结方案','start':'启动合成运行','automatic-completion':'系统自动计量、结算与清理验证','review-complete':'完成必要人工复核','acceptance-record':'业务接受或退回','export-report':'按需导出报告','export-denied':'越权导出被拒绝','clone':'克隆新修订','cancel':'停止新派发并请求取消','automatic-query-cancel-cleanup':'系统 query / cancel、核实影响及自动收尾','connector-exception-receipt':'连接器异常回执与待办','reconcile':'查看已分配的技术异常','reconcile-apply':'技术恢复后自动重试'}
roles={'engineer':'评测负责人','business':'业务负责人','quality':'必要复核人','ops':'运维（仅技术异常）','system':'系统 / 合成连接器'}
expected={'automatic-completion':'按回执中的用量及已批准价格幂等结算；自动执行已获准清理及验证。正常没有人工待办。','automatic-query-cancel-cleanup':'先停止新派发，query/cancel 并核实影响；未知不补零，复位失败隔离，未核清预算保留。','acceptance-record':'仅作业务接受或退回；不改质量门禁。费用待核查、报告未导出不阻止业务验收。','export-report':'核验报告动作权限、任务和数据范围；导出是可选动作。','export-denied':'拒绝运维角色单凭身份导出报告，已有质量与业务状态保持。','review-complete':'必要复核保持；有效强制失败仍 BLOCK，不能自动变 PASS。','reconcile-apply':'仅已分配技术异常可恢复；系统重新处理回执，不生成质量通过。','clone':'产生新任务 / 修订，原运行、报告、验收与原时间不改写。','pilot':'当前方案试评的逐检查结果单独留存。','preflight':'当前方案预检结果单独留存；缺项不得冻结。'}
def phase(action):
 if action in ['pilot','preflight','business-confirm','freeze']:return '试评与确认冻结'
 if action in ['start','automatic-completion','cancel','automatic-query-cancel-cleanup']:return '执行与系统自动收尾'
 if action in ['review-complete','acceptance-record']:return '复核与业务验收'
 if action in ['export-report','export-denied']:return '按需报告（独立分支）'
 if action in ['connector-exception-receipt','reconcile','reconcile-apply']:return '仅技术异常转维护人'
 return '需求、对象与数据准备'
def flow(sid,ops):
 w=900;bw=402;bh=88;gap=48;rowh=116;pad=24;hei=40+((len(ops)+1)//2)*rowh;out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {hei}" role="img" aria-label="共享控制器实际动作流程"><defs><marker id="a-{sid}" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0 0L7 3L0 6" fill="#7489a3"/></marker></defs>'];coords=[]
 for i,o in enumerate(ops):
  row=i//2;col=i%2 if row%2==0 else 1-i%2;coords.append((pad+col*(bw+gap),20+row*rowh))
 for (x,y),(xx,yy) in zip(coords,coords[1:]):
  if y==yy:line=f'M{x+bw if xx>x else x} {y+bh/2}L{xx if xx>x else xx+bw} {yy+bh/2}'
  else:line=f'M{x+bw/2} {y+bh}V{yy}'
  out.append(f'<path d="{line}" fill="none" stroke="#7489a3" marker-end="url(#a-{sid})"/>')
 for o,(x,y) in zip(ops,coords):
  text=labels.get(o['action'],o['action']);colour='#edf6ff' if o['actor']=='system' else '#fff'
  out.append(f'<a href="#step-{sid}-{o["n"]:02}"><rect x="{x}" y="{y}" width="{bw}" height="{bh}" rx="9" fill="{colour}" stroke="#8097b3"/><text x="{x+12}" y="{y+22}" font-size="12" font-family="sans-serif" fill="#52647a">{esc(sid.upper())}-{o["n"]:02} · {esc(roles.get(o["actor"],o["actor"]))}</text>')
  for k in range(0,len(text),23):out.append(f'<text x="{x+12}" y="{y+48+(k//23)*20}" font-size="15" font-family="sans-serif" fill="#203e60">{esc(text[k:k+23])}</text>')
  out.append('</a>')
 out.append('</svg>');return ''.join(out)

def branch(sid,b):
 ops=b['operations'];svg=flow(sid,ops);(C/(sid+'-flow.svg')).write_text(svg)
 mm=['flowchart TD']+[f' S{o["n"]}["{sid.upper()}-{o["n"]:02} {labels.get(o["action"],o["action"])}"]' for o in ops]
 mm+=[' '+ ' --> '.join('S'+str(o['n']) for o in ops)];(C/(sid+'-flow.mmd')).write_text('\n'.join(mm))
 rows=[];lastphase='需求、对象与数据准备'
 for o in ops:
  if o['action']!='role':lastphase=phase(o['action'])
  data=o.get('data');inputhtml=details('本步输入与文件内容',code(data)) if data not in [None,{},[]] else '<p>无新增填写；读取当前任务的已保存数据与配置。</p>'
  if isinstance(data,dict):
   inputhtml+=''.join('<p>'+filelink('walkthrough-assets/'+f,f)+'</p>' for f in data.get('files',[]))
  obs=o['observed'];result={'taskId':obs.get('taskId'),'states':obs.get('states'),'issues':obs.get('issues')}
  if o['action']=='pilot':result['pilot']=obs.get('pilot')
  if o['action']=='preflight':result['preflight']=obs.get('preflight')
  if o['action']=='freeze':result['manifest']=obs.get('manifest')
  if o['action'] in ['automatic-completion','automatic-query-cancel-cleanup','connector-exception-receipt','reconcile-apply']:result['ledger']=obs.get('ledger')
  rows.append([f'<span class="anchor" id="step-{sid}-{o["n"]:02}"></span><b>{sid.upper()}-{o["n"]:02}</b>',esc(roles.get(o['actor'],o['actor']))+'<small>'+lastphase+'</small>',esc(labels.get(o['action'],o['action'])),inputhtml,esc(expected.get(o['action'],'保存或读取当前精确配置；后续动作使用当前任务范围。'))+details('本次动作后的实际状态',code(result)),pill('共享控制器已执行')+'<small>'+esc(o['at'])+'</small>'])
 state=b['states'];status=table(['执行进度','质量结论','业务验收','环境清理','费用核查','报告导出'],[[pill(state.get(k)) for k in ['execution','quality','business','environment','cost','report']]])
 return '<p>'+esc(state['label'])+' · 业务完成：'+str(state['businessComplete'])+' · 收尾核清：'+str(state['closed'])+'</p>'+status+details('页面操作交互流程图', '<div class="flow-svg">'+svg+'</div>'+filelink('walkthrough-current/'+sid+'-flow.svg','下载 SVG')+' · '+filelink('walkthrough-current/'+sid+'-flow.mmd','下载 Mermaid'))+table(['步骤','角色 / 阶段','操作','填入数据 / 文件','预期与本次实际结果','执行记录'],rows)

manifest=read(D/'walkthrough-assets/manifest.json');summary=read(C/'verification-summary.json',{})
if summary.get('status')!='PASS':raise SystemExit('New verification missing or failed; do not overwrite current documentation')
browser=read(C/'browser-verification.json',{})
preserved=read(D/'history/20261028/preserved-sha256.json',{})
changed=[name for name,digest in preserved.items() if not (D/name).is_file() or hashlib.sha256((D/name).read_bytes()).hexdigest()!=digest]
if changed:raise SystemExit('Historical evidence changed: '+str(changed))
sections=[];nav=[];counts=[]
for i,s in enumerate(manifest['scenarios'],1):
 sid=s['id'];r=read(C/(sid+'-verification.json'));nav.append(f'<a href="?scene={sid}" data-nav="{sid}">{i:02} {esc(s["title"])}<small>共享控制器合成验证 · 8条路径</small></a>')
 prep=table(['平台外准备','文件 / 执行入口','平台接入'],[[esc(p['action'])+code(p['command']),'<br>'.join(esc(f) for f in p['outputs']),'使用场景源文件、输入和接入配置；当前仅合成回放，不自动访问真实模型或设备。'] for p in s['externalPreparation']])
 files='<p>'+filelink('walkthrough-assets/'+s['inputFile'],'输入 JSON')+' · '+filelink('walkthrough-assets/'+s['connectionFile'],'接入配置 JSON')+' · '+filelink('walkthrough-assets/'+s['correctFile'],'正确输出')+' · '+filelink('walkthrough-assets/'+s['failureFile'],'异常输出')+' · '+filelink('walkthrough-assets/'+sid+'/README.md','场景准备说明')+'</p>'
 conn=read(D/'walkthrough-assets'/s['connectionFile']);mapping=table(['配置项','实际值','平台接入'],[[esc(k),code(conn.get(k)),'导入接入配置，随任务方案冻结；真实网络、密钥与部署仍待验证。'] for k in ['kind','endpoint','objectVersion','adapterVersion','inputSchemaRef','outputSchemaRef','authRef','requestMapping','responseMapping']])
 bs=browser.get('scenarios',{}).get(sid,{});browserText=bs.get('summary','本场景尚未重新逐步浏览器走查；共享控制器已重跑。')
 screenshots=(filelink(bs['report'],'本轮浏览器实际下载报告') if bs.get('report') else '')+''.join('<figure><img class="terminal-shot" src="'+esc(f)+'" alt="本轮浏览器验证"><figcaption>2026-10-29 新版实际页面；验证范围见记录。</figcaption></figure>' for f in bs.get('screenshots',[]))
 main=branch(sid,r['main']);sub=''
 for j,b in enumerate(r['branches'],1):sub+=details(b['name'],branch(sid+'-b'+str(j),b))
 contents=f'''<section class="panel-view" id="scene-{sid}" data-scene="{sid}"><span class="eyebrow">SCENARIO {i:02} · 2026.10.29</span><h1>{esc(s['title'])}</h1><p>{esc(s['purpose']) if 'purpose' in s else esc(s['fixture'].get('description',''))}</p><div class="notice">当前规则：正常评测没有运维参与；系统自动计量、批准价格幂等结算及已获准清理。必要复核保持，业务方只接受或退回。报告按权限按需导出，不阻塞完成。</div><p>{pill('共享 UI 控制器合成验证 PASS')} {pill('生产验收未执行')}</p><p>浏览器验证：{esc(browserText)}</p><p>材料齐备：已生成本轮操作、输入/结果记录与流程图；12场景新视频尚未重录。材料状态与业务完成独立。</p><nav class="jump-nav"><a href="#pet-prep" hidden>准备</a><a href="#{sid}-prep">准备与接入</a><a href="#{sid}-steps">正常流程</a><a href="#{sid}-branches">退回 / 修订 / 取消 / 导出</a><a href="#{sid}-evidence">本轮证据</a></nav><h3 id="{sid}-prep">平台外准备与配置接入</h3>{prep}{files}{details('接入字段与实际值',mapping)}<h3 id="{sid}-steps">正常流程：从新建需求到业务完成</h3><p>以下是本轮在 Node DOM 替身中执行真实 UI 控制器的记录，非浏览器点击录屏。每步留存输入、试评/预检结果及状态；没有补写历史结果。系统动作标明 system，无人工结算步骤。</p>{main}<h3 id="{sid}-branches">独立分支与异常恢复</h3><p>按需报告位于业务完成之后；不导出也已完成。取消异常只有收到可验证的恢复回执后才释放预算并关闭。</p>{sub}<h3 id="{sid}-evidence">新记录与历史边界</h3><p>{filelink('walkthrough-current/'+sid+'-verification.json','下载本轮全部动作与状态记录')} · {filelink('walkthrough-current/'+sid+'-optional-report.json','下载本轮按需导出的合成报告')}</p>{screenshots}<p><a href="history/20261028/index.html?scene={sid}">查看2026-10-28历史走查（旧规则）</a> · {filelink('walkthrough-media/'+sid+'.mp4','历史视频：2026-10-28，不代表本次新版验证')}</p><p>旧日志、截图、原报告和时间均保留；历史文件摘要校验通过。</p></section>'''
 sections.append(contents);counts.append([f'<a href="?scene={sid}">{esc(s["title"])}</a>','8 条 / PASS',esc(browserText),'未验证', '未重录'])
front='<section class="panel-view" id="overview"><h1>正常评测自动收尾 · 2026.10.29</h1><p>用户确认的五条规则为本次变更基线；不将合成验证外推为生产验收。</p><div class="notice">评测完成、业务验收、环境清理、费用核查、报告导出分别记录。未导出不阻塞完成，费用待核查不改质量结论；取消未核清不得全释放或关闭。</div>'+table(['场景','共享控制器合成验证','浏览器走查范围','生产验收','新视频'],counts)+details('本次规则与验收口径', '<ol><li>系统自动采集用量、按批准价格幂等结算，连接器自动执行已获准清理；正常没有逐次人工操作。</li><li>仅技术异常转运维/对应维护人；价格、口径、费用差异转具对应权限的成本/财务人员。</li><li>报告读取与导出需要动作权限和任务/数据范围；运维角色不默认授权。</li><li>业务接受、技术恢复和费用状态不改变质量结果；必要复核及质量门禁保持。</li><li>取消先停新派发，再query/cancel并核实影响、资源和费用；未知不补零、未用预算须确认后释放。</li></ol>',True)+'<p>'+filelink('walkthrough-current/verification-summary.json','合成回放汇总：96条路径 / 852项断言')+' · '+filelink('walkthrough-current/test-results.txt','自动化测试：126项通过')+' · '+filelink('walkthrough-current/browser-verification.json','浏览器验证范围与操作记录')+' · <a href="history/20261028/index.html">历史走查原证据</a></p><p>本轮没有接入真实用量、价格审批、模型、设备或财务系统。P1账期对账/冲正/封账、P2分摊未纳入MVP。</p></section>'
nav='<a href="walkthrough.html" data-nav="overview">总览与验证边界</a>'+''.join(nav)
script="""let current=new URLSearchParams(location.search).get('scene')||'overview';function activate(id,update){if(id!=='overview'&&!document.getElementById('scene-'+id))id='overview';current=id;document.querySelectorAll('.panel-view').forEach(x=>x.classList.toggle('active',x.id===(id==='overview'?id:'scene-'+id)));document.querySelectorAll('[data-nav]').forEach(a=>{if(a.dataset.nav===id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});document.getElementById('scene-select').value=id;if(update)history.pushState({},'',id==='overview'?'walkthrough.html':'?scene='+id)}activate(current,false);document.querySelectorAll('[data-nav]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();activate(a.dataset.nav,true);scrollTo(0,0)}));document.getElementById('scene-select').addEventListener('change',e=>activate(e.target.value,true));function reveal(){const target=document.getElementById(decodeURIComponent(location.hash.slice(1)));if(!target)return;let p=target.parentElement;while(p){if(p.tagName==='DETAILS')p.open=true;p=p.parentElement}target.scrollIntoView({block:'start'})}window.addEventListener('hashchange',reveal);window.addEventListener('popstate',()=>{activate(new URLSearchParams(location.search).get('scene')||'overview',false);reveal()});reveal();"""
options='<option value="overview">总览</option>'+''.join('<option value="'+s['id']+'">'+esc(s['title'])+'</option>' for s in manifest['scenarios'])
now=datetime.datetime.now(datetime.timezone.utc).astimezone(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds')
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>正常评测自动收尾 · 场景走查</title><link rel="stylesheet" href="walkthrough.css"></head><body><header class="topbar"><div class="brand">AI评测平台<small>正常流程自动收尾 · 合成验证</small></div><a href="index.html">返回交互站点</a></header><div class="mobile-nav"><label>选择场景<select id="scene-select">'+options+'</select></label></div><div class="shell"><aside class="sidebar"><nav>'+nav+'</nav><p>规则基线：2026-10-29<br>合成 / 浏览器 / 生产验证分别记录</p></aside><main>'+front+''.join(sections)+'<p class="footer">本次文档生成：'+now+'。操作原时间见每条新日志；历史证据不改写。</p></main></div><script>'+script+'</script></body></html>'
page=page.replace('<a href="#pet-prep" hidden>准备</a>','')
(D/'walkthrough.html').write_text(page)
(D/'walkthrough.json').write_text(js({'baseline':summary['baseline'],'generatedAt':now,'scope':summary['scope'],'counts':summary['counts'],'sharedControllerAssertions':summary['assertions'],'businessCompletionBasis':'Shared runtime states, no export condition','browserVerification':browser,'historicalIntegrity':'PASS','historicalFiles':len(preserved)}))
# Verify generated file and anchor references, including expanded per-action records.
ids=set(re.findall(r'id="([^"]+)"',page));broken=[]
for link in re.findall(r'(?:href|src)="([^"]+)"',page):
 link=html.unescape(link)
 if link.startswith('#'):
  if link[1:] not in ids:broken.append(link)
 elif not link.startswith(('?','http:','https:')):
  if not (D/link.split('?')[0].split('#')[0]).is_file():broken.append(link)
validation={'generatedAt':now,'brokenLinks':broken,'historicalIntegrity':'PASS','historicalFiles':len(preserved),'sharedControllerAssertions':summary['assertions'],'status':'PASS' if not broken else 'FAIL'}
(C/'document-validation.json').write_text(js(validation));print(js(validation))
if broken:raise SystemExit(1)
