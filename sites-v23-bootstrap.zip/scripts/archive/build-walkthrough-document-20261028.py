#!/usr/bin/env python3
"""Build a traceable, evidence-driven scenario walkthrough. Never invent test completion.
Only writes walkthrough.html, walkthrough.css, walkthrough.json and walkthrough-docs/.
Run after UI evidence/media changes to refresh the published documentation.
"""
from pathlib import Path
import argparse, datetime, hashlib, html, json, re, shutil, subprocess

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,default=ROOT)
p.add_argument('--evidence-dir',type=Path,default=Path('/workspace/scratch/c9376a4f25f2/walkthrough-20261028'))
p.add_argument('--requirements',type=Path)
a=p.parse_args(); ROOT=a.repo; DIST=ROOT/'dist'; ASSETS=DIST/'walkthrough-assets'; DOCS=DIST/'walkthrough-docs'; DOCS.mkdir(exist_ok=True)
EVIDENCE=a.evidence_dir; reqpath=a.requirements or EVIDENCE/'requirements-map.json'

def read(path,default=None):
 try:return json.loads(path.read_text())
 except (OSError,json.JSONDecodeError):return default

def esc(x):return html.escape(str(x),quote=True)
def js(x):return json.dumps(x,ensure_ascii=False,indent=2)
def pill(s,kind='neutral'):return f'<span class="pill {kind}">{esc(s)}</span>'
def table(headers,rows,cls=''):
 return '<div class="table-scroll"><table class="'+cls+'"><thead><tr>'+''.join('<th scope="col">'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def detail(title,body,opened=False):return f'<details {"open" if opened else ""}><summary>{title}</summary><div class="detail-body">{body}</div></details>'
def code(x):return '<pre><code>'+esc(x if isinstance(x,str) else js(x))+'</code></pre>'
def ref(s):
 if isinstance(s,list):return '；'.join(ref(x) for x in s)
 return esc(Path(s.get('path','')).name)+':'+esc(s.get('line','—'))
def assetlink(path,label=None):
 if not path:return '—'
 f=ASSETS/path
 return f'<a href="walkthrough-assets/{esc(path)}" download>{esc(label or path)}</a>' if f.is_file() else '<span class="missing">文件尚未提供：'+esc(path)+'</span>'
def filelink(path,label=None):
 return f'<a href="{esc(path)}" download>{esc(label or Path(path).name)}</a>' if (DIST/path).is_file() else '<span class="missing">尚未生成</span>'
def copy_evidence(path):
 if not path.is_file():return None
 dest=DOCS/'evidence'/path.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(path,dest);return 'walkthrough-docs/evidence/'+path.name

def validate_operations(rows,scene,require_export=False):
 """Reject contaminated/reordered logs; incomplete logs are not completed walkthroughs."""
 if not rows:return {'status':'MISSING','valid':False,'complete':False,'errors':['没有操作日志'],'rowCount':0}
 errors=[]
 if any(not isinstance(o,dict) for o in rows):return {'status':'INVALID','valid':False,'complete':False,'errors':['操作记录必须为对象数组'],'rowCount':len(rows)}
 mixed=[i+1 for i,o in enumerate(rows) if o.get('scene')!=scene]
 if mixed:errors.append('场景混入或 scene 缺失：行 '+','.join(map(str,mixed)))
 nums=[o.get('n') for o in rows]
 if any(not isinstance(n,int) or isinstance(n,bool) or n<=0 for n in nums):errors.append('步骤 n 必须为正整数')
 else:
  if len(set(nums))!=len(nums):errors.append('步骤编号重复')
  if nums!=list(range(1,len(rows)+1)):errors.append('步骤编号不是从 1 开始连续递增的唯一序列')
 if any(not o.get('action') or not o.get('at') for o in rows):errors.append('操作名称或时间戳缺失')
 if errors:return {'status':'INVALID','valid':False,'complete':False,'errors':errors,'rowCount':len(rows)}
 report=read(EVIDENCE/f'{scene}-correct-report.json',{}) if require_export else {}
 exported=bool(rows and re.search(r'导出',rows[-1].get('action','')) and report.get('snapshot'))
 if require_export and not exported:return {'status':'IN_PROGRESS','valid':True,'complete':False,'errors':['缺少末步导出动作，或对应报告 JSON 尚不可解析；不能认定完整步骤复现'],'rowCount':len(rows)}
 return {'status':'COMPLETE','valid':True,'complete':True,'errors':[],'rowCount':len(rows),'exportReportChecked':require_export}

manifest=read(ASSETS/'manifest.json',{}); req=read(reqpath,{})
if not manifest.get('scenarios') or not req.get('mainAcceptance'):raise SystemExit('Missing manifest or requirements map')
scenarios=manifest['scenarios']; records=read(EVIDENCE/'browser-results-v17.json',read(EVIDENCE/'browser-results.json',[]))
if isinstance(records,dict):records=records.get('results',records.get('scenarios',[]))
if not isinstance(records,list):records=[]
lookup={'pdf':'SCN-PDF','pet':'SCN-PET','rag':'SCN-RAG','summary':'SCN-SUMMARY','extract':'SCN-EXTRACT','multi':'SCN-MULTI','factory':'SCN-FACTORY','math':'SCN-MODEL-BASE','file':'SCN-FILE-ORGANIZER','finetune':'SCN-FINETUNE','quantization':'SCN-QUANTIZE','edge':'SCN-EDGE'}
reverse={v:k for k,v in lookup.items()}; requirement_scenes={s['id']:s for s in req['proposedBusinessScenarios']}
PHASES=['需求与对象','数据与指标','试评与预检','确认与冻结','运行与证据','复核与报告']
PLAN_ACTIONS=['切换评测工程师','进入需求与对象','填写评测需求','填写被测对象','选择对象类型','创建评测任务','填写精确版本','填写构建证明','填写预算','选择需求部门','保存对象草稿','进入数据与指标','选择匹配场景','预览场景配置','确认载入场景','上传输入JSON','上传源文件','上传接入配置','核对输入与独立参考','确认Demo统计口径','保存数据与口径','进入试评与预检','上传外部运行输出','运行试评','执行预检','进入确认与冻结','切换业务负责人','业务确认当前方案','切换评测负责人','冻结精确版本','进入运行与证据','启动合成回放','进入复核与报告','切换质量负责人','完成必要人工复核','切换业务负责人','选择业务验收决定','填写验收依据','记录业务验收','切换平台运维','核对合成用量并结算','导出报告 JSON']
CONTROL={
 '填写精确版本':'#p-version','填写构建证明':'#p-proof','填写预算':'#p-budget','选择需求部门':'#p-department','保存对象草稿':'[data-prd="save-task"]','选择匹配场景':'#p-demo-scene','预览场景配置':'[data-prd="load-demo-preview"]','确认载入场景':'[data-prd="load-demo"]','上传输入JSON':'[data-walk-upload="input"]','上传源文件':'[data-walk-upload="source"]','上传接入配置':'[data-walk-upload="connection"]','核对输入与独立参考':'#p-input-ready','确认Demo统计口径':'#p-policy','保存数据与口径':'[data-prd="data-ready"]','上传外部运行输出':'[data-walk-upload="output"]','运行试评':'[data-prd="pilot"]','执行预检':'[data-prd="preflight"]','业务确认当前方案':'[data-prd="business-confirm"]','冻结精确版本':'[data-prd="freeze"]','启动合成回放':'[data-prd="start"]','完成必要人工复核':'[data-prd="review-complete"]','选择业务验收决定':'#p-acceptance','填写验收依据':'#p-acceptance-reason','记录业务验收':'[data-prd="acceptance-record"]','核对合成用量并结算':'[data-prd="settle-demo"]','导出报告 JSON':'[data-prd="export-report"]'}
EXPECTED={
 '创建评测任务':'生成新的需求任务，允许草稿缺项；不继承其他任务的冻结或运行。',
 '保存对象草稿':'对象、精确版本、构建证明、预算与部门回显；任务方案修订更新。',
 '确认载入场景':'载入与对象类型匹配的合成输入、指标、输出；清除旧预检与确认。',
 '上传输入JSON':'解析结构与场景匹配；保存真实文件名、字节数和 SHA-256；重新确认输入。',
 '上传源文件':'登记实际文件名、大小和摘要；此原型不解析 PDF、不长期托管源文件。',
 '上传接入配置':'导入类型、endpoint、版本、Schema、适配器及映射；标明契约核对，真实连接未验证。',
 '上传外部运行输出':'读取 output 字段并保存原始文件摘要；不是页面发起模型调用。',
 '运行试评':'显示逐项 PASS / FAIL / UNKNOWN 与必要复核；产品 FAIL 不等于试评机制失败。',
 '执行预检':'仅当前精确方案满足准备、统计、能力、权限及预算要求时 READY；缺口显示负责人。',
 '业务确认当前方案':'由已分配业务账号确认当前方案 hash，不提前批准质量通过。',
 '冻结精确版本':'由不同评测账号冻结版本、文件摘要、配置、规则及口径；旧确认失效时阻断。',
 '启动合成回放':'启动时复检授权与 hash，预留合成预算，产生运行和结果快照。',
 '完成必要人工复核':'追加快照；确认已有证据，不把有效 FAIL 自动改成 PASS。',
 '记录业务验收':'记录接受/附条件接受/退回、理由及快照；与质量门禁独立。',
 '核对合成用量并结算':'确认费用结算并核对环境复位；显示明确流程终态。',
 '导出报告 JSON':'下载与当前快照一致的 JSON；保留历史及合成范围声明。'}

def planned(s):
 data={1:'林工',3:f"验证{s['title']}的业务正确性、证据完整性与异常分支（合成验收）",4:s['object'],5:s['category'],7:s['version'],8:s['proof'],9:'10元（合成）',10:s['fixture'].get('department','企业业务'),13:s['title'],16:s['inputFile'],17:s['sourceFiles'],18:s['connectionFile'],19:True,20:True,23:s['correctFile'],27:'赵经理',29:'林工',34:'周经理',36:'赵经理',37:'ACCEPTED',38:'合成验收：当前冻结输入、版本和全部强制检查满足；只接受本次离线证据回放，不代表真实服务验收。',40:'王工'}
 return [{'n':i,'scene':s['id'],'action':t,'data':data.get(i),'recorded':False} for i,t in enumerate(PLAN_ACTIONS,1)]

def phase_of(op):
 if 'phase' in op:return op['phase']
 n=op['n'];return 0 if n<=11 else 1 if n<=21 else 2 if n<=25 else 3 if n<=30 else 4 if n<=32 else 5

def wrap(text,width=19):
 return [text[i:i+width] for i in range(0,len(text),width)] or ['']

def operation_svg(sid,phase,ops):
 # At most two operations across. Snake ordering keeps each edge local and readable.
 w=840;boxw=366;boxh=86;gapx=54;gapy=38;pad=22;rows=(len(ops)+1)//2;h=52+rows*(boxh+gapy)
 out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" role="img" aria-label="{esc(PHASES[phase])}逐操作流程图"><defs><marker id="arrow-{sid}-{phase}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#8194ad"/></marker></defs><rect width="100%" height="100%" rx="12" fill="#f6f8fc"/><text x="22" y="29" fill="#172f4e" font-family="sans-serif" font-size="17" font-weight="700">阶段 {phase+1} · {esc(PHASES[phase])}</text>']
 positions=[]
 for idx,op in enumerate(ops):
  row=idx//2;col=idx%2 if row%2==0 else 1-idx%2;x=pad+col*(boxw+gapx);y=48+row*(boxh+gapy);positions.append((x,y))
 for i in range(len(positions)-1):
  x,y=positions[i];xx,yy=positions[i+1]
  if y==yy:
   start=(x+boxw,y+boxh/2) if xx>x else (x,y+boxh/2);end=(xx,yy+boxh/2) if xx>x else (xx+boxw,yy+boxh/2)
  else:start=(x+boxw/2,y+boxh);end=(xx+boxw/2,yy)
  out.append(f'<path d="M{start[0]} {start[1]}L{end[0]} {end[1]}" fill="none" stroke="#8194ad" stroke-width="2" marker-end="url(#arrow-{sid}-{phase})"/>')
 for op,(x,y) in zip(ops,positions):
  recorded=op.get('recorded');color='#28736b' if recorded else '#8a7243';status='已记录操作' if recorded else '待执行 / 无日志';step=f"{sid}-{op['n']:02}"
  out.append(f'<a href="#step-{step}"><rect x="{x}" y="{y}" width="{boxw}" height="{boxh}" rx="10" fill="white" stroke="{color}" stroke-width="1.4"/><text x="{x+14}" y="{y+22}" font-family="sans-serif" font-size="12" fill="{color}">{esc(step.upper())} · {status}</text>')
  for k,line in enumerate(wrap(op['action'],20)):out.append(f'<text x="{x+14}" y="{y+47+k*20}" font-family="sans-serif" font-size="16" fill="#172f4e">{esc(line)}</text>')
  out.append('</a>')
 out.append('</svg>');return ''.join(out)

BRANCHES=[
 ('G','缺口阻断',[('创建缺项草稿','保留对象版本/输入/接入/参考或预算缺口。'),('执行预检','必须出现具体缺口与责任人，禁止冻结。'),('回到对应页面补齐','保存后旧预检和确认失效。'),('重新试评和预检','READY 后方可继续确认与冻结。')]),
 ('R','异常退回整改',[('上传异常输出','使用 output-failure.json，不覆盖已冻结结果。'),('试评、预检、确认冻结并运行','复用主线 24—33，结果可含有效 FAIL 和 UNKNOWN。'),('完成必要复核','未完成时 INCONCLUSIVE；确认有效强制 FAIL 后 BLOCK。'),('业务选择退回整改并填原因','业务验收 RETURNED，不修改质量结论。'),('运维核对复位与结算','BLOCK + RETURNED + 清理和费用已核清，可形成明确终态。')]),
 ('V','克隆新修订',[('点击克隆新修订','保留原任务、原始输出和历史快照。'),('核对版本并上传正确输出','使用 output-correct.json；需要时更新对象版本和构建证明。'),('重新试评、预检和双角色确认','原确认、冻结与运行不会继承。'),('冻结新方案、运行并复核','产生新 run 和新 snapshot；关联原任务。'),('业务接受并完成清理结算','与旧 BLOCK / RETURNED 并列，不覆盖历史。')]),
 ('A','接受与关闭',[('完成必要人工复核','没有有效强制失败且证据齐全时质量 PASS。'),('业务选择接受或有条件接受','填写依据与条件；接受不能覆盖质量门禁。'),('核对环境与费用','已复位且用量核清后记录关闭。')]),
 ('C','取消与清理',[('运行中停止并查询状态','停止新派发；未决动作先查询，不盲目重试。'),('切换平台运维并查询实际状态','执行 RECONCILING、环境 UNKNOWN、费用 PENDING_QUERY 分列。'),('尝试复位并对账','复位失败隔离，保留责任人；未知费用不当零。'),('确认取消终态','仅已查询、已复位且已结算时 CANCELLED 闭环；无质量快照不伪造。')])]

def branch_mermaid(sid):
 lines=['flowchart TD']
 for bid,title,steps in BRANCHES:
  lines.append(f'  subgraph {bid}["{title}"]')
  for i,(act,_) in enumerate(steps,1):lines.append(f'    {bid}{i}["{bid}{i} {act}"]')
  lines.append('    '+' --> '.join(f'{bid}{i}' for i in range(1,len(steps)+1)));lines.append('  end')
 lines+=['  G4 --> R1','  R5 --> V1','  V5 --> A3','  C3 -->|未决或复位失败| C2']
 return '\n'.join(lines)+'\n'

def branch_svg(sid):
 # Five compact vertical lanes, split into two rows to avoid a wide diagram.
 width=960;lane_w=292;pad=20;gap=20;rowspec=[BRANCHES[:3],BRANCHES[3:]];out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} 980" role="img" aria-label="异常与终态分支流程"><rect width="100%" height="100%" rx="12" fill="#f6f8fc"/><defs><marker id="ba-{sid}" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0 0L7 3.5L0 7" fill="#8194ad"/></marker></defs>']
 for row,branches in enumerate(rowspec):
  for col,(bid,title,steps) in enumerate(branches):
   x=pad+col*(lane_w+gap);y=20+row*520;out.append(f'<text x="{x}" y="{y+20}" font-family="sans-serif" font-size="17" font-weight="700" fill="#173253">{bid} · {esc(title)}</text>')
   for idx,(act,_) in enumerate(steps):
    yy=y+38+idx*85
    if idx:out.append(f'<path d="M{x+lane_w/2} {yy-14}V{yy-2}" stroke="#8194ad" stroke-width="2" marker-end="url(#ba-{sid})"/>')
    out.append(f'<a href="#branch-{sid}-{bid}{idx+1}"><rect x="{x}" y="{yy}" width="{lane_w}" height="70" rx="9" fill="#fff" stroke="#9eadc0"/><text x="{x+12}" y="{yy+20}" font-family="sans-serif" font-size="11" fill="#61738a">{sid.upper()}-{bid}{idx+1} · 分支操作定义</text>')
    for n,line in enumerate(wrap(act,17)):out.append(f'<text x="{x+12}" y="{yy+42+n*18}" font-family="sans-serif" font-size="14" fill="#173253">{esc(line)}</text>')
    out.append('</a>')
 out.append('</svg>');return ''.join(out)

def operation_data(value):
 if value is None or (isinstance(value,(dict,list)) and not value):return '<span class="muted">本步无新增填写或上传；按钮操作可沿用前序数据。</span>'
 if isinstance(value,str) and (ASSETS/value).is_file():return assetlink(value)
 if isinstance(value,list) and all(isinstance(v,str) for v in value):return '<br>'.join(assetlink(v) if (ASSETS/v).is_file() else esc(v) for v in value)
 if isinstance(value,(dict,list)):return detail('查看本步填写 / 上传记录',code(value))
 return esc('勾选' if value is True else '未勾选' if value is False else value)

# An action's data contains only new UI input, never its request/response or state.
# Describe reuse from earlier recorded uploads; never promote planned or later data
# into evidence that a historical step consumed it or produced a particular result.
REUSED_UPLOADS={
 '保存数据与口径':['input','source','connection'],
 '运行试评':['input','source','connection','output'],
 '执行预检':['input','source','connection','output'],
 '业务确认当前方案':['input','source','connection','output'],
 '评测负责人冻结':['input','source','connection','output'],
 '启动合成回放':['input','source','connection','output'],
 '完成必要人工复核':['source','output'],
 '业务负责人记录验收':['output'],
 '运维核对合成用量并结算':['connection'],
 '导出报告 JSON':['input','source','connection','output'],
}
REPORT_CONTEXT={
 '运行试评':('本步试评结果未单独留存。可核对后续报告中的冻结输入、输出与规则；后续运行结果不能代替本步试评结果。','inputs'),
 '执行预检':('本步预检清单与判定未单独留存。后续冻结清单不能替代本步逐项预检结果。','manifest'),
 '业务确认当前方案':('本步业务确认回执未单独留存。后续报告记录了冻结方案及成员，不等于确认回执。','manifest'),
 '评测负责人冻结':('以下为后续导出报告留存的冻结清单，可核对精确版本与摘要。','manifest'),
 '启动合成回放':('以下为后续导出报告留存的运行与质量快照，不是本步启动即时响应。','snapshot'),
 '完成必要人工复核':('以下为后续导出报告留存的质量快照；本步独立复核操作回执未单独留存。','snapshot'),
 '业务负责人记录验收':('以下为后续导出报告留存的业务验收记录。','acceptance'),
 '运维核对合成用量并结算':('费用与复位终态见本场景保存的结果页面；本步结算明细未单独留存。','terminal'),
 '导出报告 JSON':('下载本次实际导出报告，包含质量快照、冻结清单、历史与业务验收。','report'),
}

def step_context(op,ops,sid,report):
 if not op.get('recorded'):return None
 action=op['action'];latest={}
 for previous in ops:
  if previous['n']>=op['n']:break
  if not previous.get('recorded'):continue
  match=re.fullmatch('上传文件：(input|source|connection|output)',previous['action'])
  value=previous.get('data')
  if match and isinstance(value,dict) and isinstance(value.get('files'),list):
   latest[match.group(1)]={'kind':match.group(1),'step':f'{sid}-{previous["n"]:02}','files':value['files']}
 related=[latest[k] for k in REUSED_UPLOADS.get(action,[]) if k in latest]
 evidence=None
 if action in REPORT_CONTEXT:
  note,kind=REPORT_CONTEXT[action];snap=report.get('snapshot',{});mf=snap.get('manifest',{})
  fields={
   'inputs':{k:mf[k] for k in ['importedInput','outputs','metricIds','policy'] if k in mf},
   'manifest':{k:mf[k] for k in ['id','hash','at','objectVersion','members','files','sourceFiles','dependencies'] if k in mf},
   'snapshot':{k:snap[k] for k in ['id','runId','at','rows','summary'] if k in snap},
   'acceptance':report.get('businessAcceptance'),
  }.get(kind)
  evidence={'note':note,'relationship':'LATER_EXPORTED_REPORT_NOT_STEP_RESPONSE','reportFile':f'walkthrough-docs/evidence/{sid}-correct-report.json','fields':fields,'kind':kind}
 if not related and evidence is None:return None
 return {'reusedUploads':related,'reuseBasis':'Earlier recorded uploads; no per-action request capture','resultEvidence':evidence}

def operation_materials(op,sid):
 value=op.get('data');out=operation_data(value);ctx=op.get('dataContext') or {}
 if op['action'].startswith('上传文件：') and isinstance(value,dict):
  for path in value.get('files',[]):
   out+='<p>'+assetlink(path)+'</p>'+source_file_preview(path)
 related=ctx.get('reusedUploads',[])
 if related:
  out+='<p><strong>沿用的前序材料</strong></p>'
  for item in related:
   out+='<p><a href="#step-'+esc(item['step'])+'">'+esc(item['step'].upper())+'</a> · '+esc(item['kind'])+'<br>'+'<br>'.join(assetlink(f) for f in item['files'])+'</p>'
  previews=''.join(source_file_preview(f) for item in related for f in item['files'])
  if previews:out+=detail('查看关联文件内容',previews)
 evidence=ctx.get('resultEvidence')
 if evidence:
  out+='<p class="step-evidence">'+esc(evidence['note'])+'</p>'
  if evidence.get('fields'):
   out+=detail('查看后续报告留存字段',code(evidence['fields']))
  out+='<p><a href="#'+esc(sid)+'-evidence">查看本场景结果依据</a>'
  if (DIST/evidence['reportFile']).is_file():out+=' · '+filelink(evidence['reportFile'],'下载后续导出报告')
  out+='</p>'
 return out

def source_file_preview(path):
 f=ASSETS/path
 if not f.is_file():return ''
 if f.suffix.lower() in ['.json','.jsonl','.txt','.csv','.md']:
  text=f.read_text(errors='replace');return detail('查看内容 · '+esc(path),code(text[:16000])+('<p class="muted">页面仅显示前 16,000 字符；下载原文件查看全部。</p>' if len(text)>16000 else ''))
 return ''

summary=[];scene_html=[];missing=[]
for s in scenarios:
 sid=s['id'];rsc=requirement_scenes[lookup[sid]];rawops=read(EVIDENCE/f'{sid}-operations.json',[])
 if isinstance(rawops,dict):rawops=rawops.get('operations',[])
 rawops=rawops if isinstance(rawops,list) else []
 log_validation=validate_operations(rawops,sid,require_export=True)
 invalid_row_count=len(rawops) if log_validation['status']=='INVALID' else 0
 if log_validation['status']=='INVALID':rawops=[]
 ops=[{**o,'n':int(o.get('n',i+1)),'recorded':True} for i,o in enumerate(rawops)]
 # Pending operations are explicitly labelled; a log of 41 actions is never upgraded to 42 completed actions.
 if not ops:ops=planned(s)
 elif max(o['n'] for o in ops)<42:
  present={o['n'] for o in ops};ops.extend(o for o in planned(s) if o['n'] not in present and o['n']>max(x['n'] for x in rawops))
 latest=next((r for r in reversed(records) if r.get('id',r.get('scene'))==sid and r.get('mode','correct')=='correct'),{})
 report=read(EVIDENCE/f'{sid}-correct-report.json',{});snapshot=report.get('snapshot',{});sm=snapshot.get('summary',{});acceptance=report.get('businessAcceptance') or {}
 textpath=EVIDENCE/f'{sid}-correct-result.txt';resulttext=textpath.read_text() if textpath.is_file() else ''
 terminal_record_exists=latest.get('result',latest.get('status'))=='UI_CLOSED'
 closed=terminal_record_exists and log_validation['complete']
 state='原型逐步闭环已记录' if closed else '日志无效 · 不计逐步验证' if log_validation['status']=='INVALID' else '已有终态 · 步骤记录未完整' if terminal_record_exists else '操作执行中' if rawops else '尚无完整操作记录'
 terminal_match=re.search(r'执行\s+(\w+)\s*/\s*环境\s+(\w+)\s*/\s*费用\s+(\w+)',resulttext)
 terminal_fields=dict(zip(['execution','environment','settlement'],terminal_match.groups())) if terminal_match else {}
 evidence=[]
 for path in [EVIDENCE/f'{sid}-operations.json',EVIDENCE/f'{sid}-correct-report.json',textpath,EVIDENCE/f'{sid}-failure-result.txt',EVIDENCE/f'{sid}-failure-report.json',EVIDENCE/f'{sid}-terminal.jpg']:
  target=copy_evidence(path)
  if target:evidence.append(target)
 for path in EVIDENCE.glob(f'{sid}-*branch*.json'):
  target=copy_evidence(path)
  if target:evidence.append(target)
 for pattern in [f'{sid}-clone-*',f'{sid}-cancel-*',f'{sid}-gap-*']:
  for path in EVIDENCE.glob(pattern):
   if path.suffix in ['.json','.txt','.jpg']:
    target=copy_evidence(path)
    if target and target not in evidence:evidence.append(target)
 branch_logs={};extra_operations_html=''
 for path in sorted(EVIDENCE.glob(f'{sid}-*-operations.json')):
  branch_name=path.name[len(sid)+1:-len('-operations.json')]
  extra=read(path,[])
  if isinstance(extra,dict):extra=extra.get('operations',[])
  if not isinstance(extra,list) or not extra:continue
  extra_validation=validate_operations(extra,sid)
  if not extra_validation['valid']:
   target=copy_evidence(path)
   if target:evidence.append(target)
   extra_operations_html+=detail('无效分支日志 · '+esc(branch_name),'<p class="notice">该日志不计入有效动作或分支验证：'+esc('；'.join(extra_validation['errors']))+'</p><p>'+filelink(target,'下载原始日志供诊断')+'</p>')
   continue
  extra=[{**o,'n':int(o.get('n',i+1)),'recorded':True,'branch':branch_name} for i,o in enumerate(extra)]
  branch_logs[branch_name]=extra;target=copy_evidence(path)
  if target:evidence.append(target)
  extra_id=sid+'-'+branch_name
  extra_svg=operation_svg(extra_id,5,extra)
  (DOCS/f'{extra_id}-flow.svg').write_text(extra_svg)
  extra_mm=['flowchart TD']+[f'  S{o["n"]}["{extra_id.upper()}-{o["n"]:02} {o["action"]}"]' for o in extra]
  extra_mm.append('  '+' --> '.join(f'S{o["n"]}' for o in extra));(DOCS/f'{extra_id}-flow.mmd').write_text('\n'.join(extra_mm)+'\n')
  extra_rows=[[f'<span id="step-{extra_id}-{o["n"]:02}" class="anchor"></span><strong>{extra_id.upper()}-{o["n"]:02}</strong>',esc(o['action']),operation_data(o.get('data')),esc(o.get('at','时间未提供'))] for o in extra]
  extra_operations_html+=detail('实际分支操作 · '+esc(branch_name)+' · '+str(len(extra))+' 步','<div class="flow-svg">'+extra_svg+'</div>'+table(['步骤','实际操作','实际填写 / 上传','操作时间'],extra_rows)+'<p>'+filelink(target,'下载原始操作日志')+' · '+filelink(f'walkthrough-docs/{extra_id}-flow.svg','下载 SVG')+' · '+filelink(f'walkthrough-docs/{extra_id}-flow.mmd','下载 Mermaid')+'</p>')
  for suffix in ['result.txt','blocked.txt','quarantined.txt']:
   observed=EVIDENCE/f'{sid}-{branch_name}-{suffix}'
   if observed.is_file():extra_operations_html+=detail('该分支的实际页面状态 · '+esc(suffix),code(observed.read_text()))
 for op in ops:
  context=step_context(op,ops,sid,report)
  if context:op['dataContext']=context
 opfile=DOCS/f'{sid}-operations.json';opfile.write_text(js({'scene':sid,'recordedCount':len(rawops),'invalidRowCount':invalid_row_count,'validation':log_validation,'operations':ops,'recordingBoundary':'data 只记录本步新增填写/上传，不是完整请求、响应或状态。dataContext 根据前序上传日志关联材料；后续导出报告与本步即时结果明确区分。原始日志保持不变。只有场景ID与顺序编号校验通过的日志才计有效动作。末步导出及对应报告存在后才计完整步骤复现；无日志步骤为待执行定义。'}))
 source_hashes=[]
 for f in s['files']:
  path=ASSETS/f['path'];actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
  source_hashes.append({**f,'exists':path.is_file(),'actualSha256':actual,'digestMatches':actual==f.get('sha256')})
  if not path.is_file():missing.append(f['path'])
 video=DIST/'walkthrough-media'/f'{sid}.mp4';video_valid=video.is_file() and video.stat().st_size>0
 mediafolder=DIST/'walkthrough-media'/sid;shots=sorted(mediafolder.glob('*.jpg')) if mediafolder.is_dir() else []
 # Classify actual navigation and actor switches; some scenes require no human review.
 phase=0;role='评测工程师'
 role_names={'engineer':'评测工程师','business':'业务负责人','quality':'质量负责人','ops':'平台运维'}
 for op in ops:
  if op.get('recorded'):
   match=re.match(r'^([1-6])\s',op['action'])
   if match:phase=int(match.group(1))-1
   data=op.get('data')
   if op['action']=='切换演示角色' and isinstance(data,dict):role=role_names.get(data.get('value'),role)
   op['phase']=phase;op['actor']=role
 mermaid=['flowchart TD'];diagramhtml='';steptables=''
 for phase in range(6):
  selected=[o for o in ops if phase_of(o)==phase]
  if not selected:continue
  svg=operation_svg(sid,phase,selected);svgfile=DOCS/f'{sid}-phase-{phase+1}.svg';svgfile.write_text(svg)
  ml=['flowchart TD']
  for op in selected:ml.append(f'  S{op["n"]}["{sid.upper()}-{op["n"]:02} {op["action"]} · {"已记录" if op.get("recorded") else "待执行"}"]')
  ml.append('  '+' --> '.join(f'S{o["n"]}' for o in selected));(DOCS/f'{sid}-phase-{phase+1}.mmd').write_text('\n'.join(ml)+'\n')
  mermaid.append(f'  subgraph P{phase+1}["{PHASES[phase]}"]');mermaid+=['  '+line for line in ml[1:]];mermaid.append('  end')
  diagramhtml+=detail(f'{phase+1}. {PHASES[phase]} · {len(selected)} 个操作',f'<div class="flow-svg">{svg}</div><p class="downloads">'+filelink(f'walkthrough-docs/{sid}-phase-{phase+1}.svg','下载 SVG')+' · '+filelink(f'walkthrough-docs/{sid}-phase-{phase+1}.mmd','下载 Mermaid 源码')+'</p>',phase==0)
  rows=[]
  for op in selected:
   role=op.get('actor') or ('业务负责人' if op['n'] in [27,28,36,37,38,39] else '质量负责人' if op['n'] in [34,35] else '平台运维' if op['n'] in [40,41] else '评测工程师')
   status=pill('已记录动作','good')+'<small>'+esc(op.get('at','时间未提供'))+'</small>' if op.get('recorded') else pill('待执行 / 无日志','warn')
   alias={'保存草稿':'保存对象草稿','载入此 Demo':'确认载入场景','上传文件：input':'上传输入JSON','上传文件：source':'上传源文件','上传文件：connection':'上传接入配置','上传文件：output':'上传外部运行输出','评测负责人冻结':'冻结精确版本','业务负责人记录验收':'记录业务验收','运维核对合成用量并结算':'核对合成用量并结算'}.get(op['action'],op['action'])
   expected=EXPECTED.get(alias,'页面导航或填写后正确回显；不自动改变质量与业务终态。')
   rows.append([f'<span id="step-{sid}-{op["n"]:02}" class="anchor"></span><strong>{sid.upper()}-{op["n"]:02}</strong>',esc(role)+'<small>'+esc(PHASES[phase])+'</small>',esc(op['action'])+(('<small class="code">'+esc(CONTROL[op['action']])+'</small>') if op['action'] in CONTROL else ''),operation_materials(op,sid),esc(expected),status])
  steptables+=detail(f'{phase+1}. {PHASES[phase]} · 操作 {selected[0]["n"]}—{selected[-1]["n"]}',table(['步骤','角色 / 页面','操作与控件','本步输入 / 沿用材料 / 结果依据','预期与观察点','本轮动作记录'],rows,'operations'),phase==0)
 (DOCS/f'{sid}-flow.mmd').write_text('\n'.join(mermaid)+'\n')
 bsvg=branch_svg(sid);(DOCS/f'{sid}-branches.svg').write_text(bsvg);(DOCS/f'{sid}-branches.mmd').write_text(branch_mermaid(sid))
 branchrows=[]
 for bid,title,steps in BRANCHES:
  for i,(act,expected) in enumerate(steps,1):
   actual='该分支尚无逐操作日志，不能据流程定义认定已测。'
   if bid=='A' and closed:actual='接受主线有操作日志及 UI_CLOSED 记录；质量、业务与费用依据见下方实际证据。'
   if bid=='R' and (EVIDENCE/f'{sid}-failure-result.txt').is_file():actual='存在异常结果页面文本；若无对应分支操作日志，不计整条分支已验证。'
   branch_key={'G':'gap','R':'failure','V':'clone','C':'cancel'}.get(bid)
   if branch_key in branch_logs:actual=f'已有 {len(branch_logs[branch_key])} 条本轮 {branch_key} 操作日志；逐操作表与图见下方。终态仍以该分支实际报告/页面为准。'
   branchrows.append([f'<span id="branch-{sid}-{bid}{i}" class="anchor"></span><strong>{sid.upper()}-{bid}{i}</strong>',esc(title),esc(act),esc(expected),esc(actual)])
 preparatory=[]
 for x in s['externalPreparation']:
  status='可复现步骤；以执行验证记录说明实际运行方式。'
  preparatory.append([esc(x['step']),esc(x['who']),esc(x['action'])+code(x['command']),'<br>'.join(esc(f) for f in x['outputs']),esc(status)])
 pv=s.get('externalPreparationValidation',{});prep_actual=f'<div class="notice good"><strong>已实际执行的范围：</strong>{esc(pv.get("scope","尚无执行证据"))}<br>执行记录：<code>{esc(pv.get("executedCommand","未提供"))}</code> · {esc(pv.get("executedAt",""))}<br>{esc(pv.get("runnerInvocation",""))}<br>{assetlink(pv.get("evidenceFile"),"下载本机执行验证记录")}</div>'
 prep_actual+='<p>下列 runner 命令是可复现入口；本轮 selftest 直接调用 runner 函数，并分别验证离线与本机 HTTP。命令清单中的动态端口是实际测试端口；8765 是复现示例。未运行训练、真实模型推理、车辆动作、真实文件移动或生产系统。</p>'
 conn=read(ASSETS/s['connectionFile'],{})
 fieldmap=[('外部接入类型','#w-kind','kind'),('服务或网页入口','#w-endpoint','endpoint'),('运行命令 / 镜像入口','#w-command','command'),('外部对象精确版本','#w-version','objectVersion'),('适配器版本','#w-adapter','adapterVersion'),('输入 Schema','#w-input-schema','inputSchemaRef'),('输出 Schema','#w-output-schema','outputSchemaRef'),('凭证引用','#w-auth','authRef'),('超时（毫秒）','#w-timeout','timeoutMs')]
 mapping=table(['页面控件','配置键','本包实际值','行为边界'],[[esc(label)+'<small class="code">'+esc(selector)+'</small>',esc(key),code(conn.get(key,conn.get('image',conn.get('entrypoint','未配置 / 本机离线模式不需要')))),'导入 connection.json 回填；当前仅校验字段，不从浏览器连通服务。'] for label,selector,key in fieldmap])
 mapping+=detail('完整接入配置、请求与响应映射',code(conn))
 uploadrows=[]
 uploaded={}
 for op in rawops+[op for values in branch_logs.values() for op in values]:
  if '上传' in op.get('action',''):
   values=op.get('data');values=values.get('files',[]) if isinstance(values,dict) else values;values=values if isinstance(values,list) else [values]
   for v in values:
    if isinstance(v,str):uploaded[v]=op
 for u in s.get('uploadOrder',[]):
  op=uploaded.get(u['file']);uploadrows.append([esc(u['kind'])+('<small>'+esc(u.get('branch',''))+'</small>'),assetlink(u['file']),esc(u['role']),pill('有上传动作记录','good')+f'<small>{esc(op.get("branch","主线"))} · 步骤 {op["n"]}</small>' if op else pill('准备包已备；本轮未记录上传','warn')])
 filesrows=[]
 for f in source_hashes:
  filesrows.append([assetlink(f['path']),esc(f['bytes']),'<code class="digest">'+esc(f.get('actualSha256') or '缺失')+'</code>',pill('文件存在 / 摘要一致','good') if f['digestMatches'] else pill('摘要不一致或缺失','warn'),'独立评分侧；禁止发给被测对象' if f.get('purpose')=='scorer_only' else '输入 / 配置 / 合成输出；用途见文件'])
 media='<p class="notice">视频尚未生成；不展示空播放器或旧视频。</p>'
 if video_valid:media=f'<video controls preload="metadata" playsinline aria-label="{esc(s["title"])}逐步演示"><source src="walkthrough-media/{sid}.mp4" type="video/mp4">浏览器不支持视频，请下载查看。</video><p>'+filelink(f'walkthrough-media/{sid}.mp4','下载逐步演示 MP4')+'</p>'
 media+='<p class="muted">视频类型：本次实际页面截图按操作步骤合成的逐步演示，非连续录屏，不呈现实时点击过程。操作日志的时间戳与视频播放时长不同。</p>'
 if shots:
  frame_map=read(mediafolder/'frames.json',{}).get('frames',[])
  def frame_caption(i):
   f=frame_map[i] if i<len(frame_map) else {};return '操作 '+str(f.get('operation','—'))+' 附近页面：'+f.get('action','实际截图')
  media+='<div class="shot-grid">'+''.join(f'<figure><a href="walkthrough-media/{sid}/{esc(x.name)}" target="_blank"><img loading="lazy" src="walkthrough-media/{sid}/{esc(x.name)}" alt="{esc(s["title"])} 页面帧 {esc(x.stem)}"></a><figcaption>{esc(frame_caption(i))}</figcaption></figure>' for i,x in enumerate(shots))+'</div>'
 elif (EVIDENCE/f'{sid}-terminal.jpg').is_file():media+=f'<figure><a href="walkthrough-docs/evidence/{sid}-terminal.jpg" target="_blank"><img class="terminal-shot" loading="lazy" src="walkthrough-docs/evidence/{sid}-terminal.jpg" alt="{esc(s["title"])}实际终态截图"></a><figcaption>本次终态截图；完整分步截图尚未提供。</figcaption></figure>'
 checks=s['fixture']['checks'];checkrows=[]
 for c in checks:
  localid=f'LOCAL/{sid}/{c["id"]}'
  checkrows.append([esc(localid),esc(c['name']),esc(c['metric']),code(c.get('expected')),esc('需人工复核' if c.get('review') else '确定性检查')])
 trace=table(['证据维度','本次记录'],[['浏览器闭环',pill(state,'good' if closed else 'warn')+('<small>任务 '+esc(latest.get('task','未提供'))+' · '+esc(latest.get('at',''))+'</small>')],['已记录操作',str(len(rawops))+' 次主线；另有 '+str(sum(len(x) for x in branch_logs.values()))+' 次分支日志动作。文档中待执行步骤不自动计入。'],['质量快照',esc(sm.get('verdict','未提供'))+' · '+esc(snapshot.get('id','无快照文件'))],['业务验收',esc(acceptance.get('status','未提供'))+'<small>'+esc(acceptance.get('reason',''))+'</small>'],['执行 / 环境 / 费用',esc(' / '.join(terminal_fields.get(k,'页面文本未提供') for k in ['execution','environment','settlement']))+'<small>来源为本轮实际结果页面文字；闭环还要求必要复核及针对当前快照的业务验收。</small>'],['真实服务 / 模型 / 设备','未验证；不得由本轮合成闭环替代。'],['证据文件','<br>'.join(filelink(x) for x in evidence) or '尚未生成']])
 trace+='<div class="notice"><strong>日志完整性：'+esc(log_validation['status'])+'</strong>。'+esc('；'.join(log_validation['errors']) or '场景一致、从 1 连续唯一编号；末步导出动作与可解析报告均存在。')+'<br>原始终态页面记录：'+('存在' if terminal_record_exists else '尚未提供')+'；它与操作日志校验结果分开记录。</div>'
 if resulttext:trace+=detail('实际结果页面文本',code(resulttext))
 if snapshot:
  trace+=detail('实际快照字段与文件摘要',code({'snapshot':snapshot.get('id'),'summary':sm,'objectVersion':snapshot.get('manifest',{}).get('objectVersion'),'files':snapshot.get('manifest',{}).get('files'),'sourceFiles':snapshot.get('manifest',{}).get('sourceFiles'),'scope':report.get('scope')}))
 htmlpart=f'''<section class="scene panel-view" id="scene-{sid}" data-scene="{sid}">
 <div class="scene-heading"><div><span class="eyebrow">SCENARIO {scenarios.index(s)+1:02} / 12 · {esc(s['category'])}</span><h2>{esc(s['title'])}</h2><p>{esc(s['fixture'].get('description',''))}</p></div>{pill(state,'good' if closed else 'warn')}</div>
 <div class="tag-row">{''.join(pill(x) for x in rsc['mainAcceptance'])}{pill(s['taskTypeVersionRef'])}{pill('SYNTHETIC / LOCAL REPLAY','warn')}</div>
 <div class="notice"><strong>本案边界：</strong>{esc(s['limits'])}<br>{esc(manifest['siteIntegrationBoundary'])}</div>
 <div class="notice"><strong>操作日志完整性：{esc(log_validation['status'])}</strong> · {esc('；'.join(log_validation['errors']) or '场景与连续编号有效，末步导出及对应报告已校验。')} {('原始 '+str(invalid_row_count)+' 行不计有效操作；下表回退为待执行定义。') if invalid_row_count else ''}</div>
 <nav class="jump-nav" aria-label="本场景章节"><a href="#{sid}-media">演示</a><a href="#{sid}-prep">准备与接入</a><a href="#{sid}-flow">流程图</a><a href="#{sid}-steps">操作表</a><a href="#{sid}-branches">分支</a><a href="#{sid}-evidence">证据与终态</a></nav>
 <h3 id="{sid}-media">场景 Demo 与截图</h3>{media}
 <h3 id="{sid}-prep">平台外准备与配置接入</h3>{prep_actual}{table(['顺序','责任人','准备动作与可复现命令','预期产物','执行口径'],preparatory)}
 <p class="downloads">{assetlink(s['readme'],'下载场景准备说明')} · {assetlink('common/runner.py','下载离线执行器代码')} · {assetlink('common/replay_server.py','下载模拟 HTTP 服务代码')} · {assetlink('common/selftest.py','下载自测代码')} · {assetlink('walkthrough-assets.zip','下载完整准备包 ZIP')}</p>
 {detail('生产联测仍需提供的外部准备','<ol>'+''.join('<li>'+esc(x)+'</li>' for x in rsc['externalPreparation'])+'</ol><p class="notice">以上为生产待准备，不是本次已完成的部署、训练、模型调用或设备实测。</p>',True)}
 {detail('接入字段如何进入当前平台控件',mapping,True)}
 {detail('上传顺序与本轮上传记录',table(['材料类型','真实文件下载','责任人','本轮记录'],uploadrows),True)}
 {detail('真实存在的准备文件与 SHA-256',table(['文件','字节','SHA-256','核验','访问 / 用途边界'],filesrows))}
 {detail('本案完整填写数据与输出样例',source_file_preview(s['inputFile'])+source_file_preview(s['failureFile'])+source_file_preview(s['correctFile']))}
 <h3 id="{sid}-flow">页面操作交互流程图</h3><p>每个节点与操作表使用同一编号。绿色表示有动作日志，棕色表示待执行；动作记录不自动证明预期通过。点击图中节点可定位对应表格行。</p>{diagramhtml}<p>{filelink(f'walkthrough-docs/{sid}-flow.mmd','下载完整 Mermaid 源码')}</p>
 <h3 id="{sid}-steps">逐操作步骤表</h3><p>已记录 {len(rawops)} 次操作。按六阶段折叠；填写值、上传文件及时间戳来自本轮日志。没有日志的步骤明确标为待执行。</p><p class="notice">数据说明：日志只记录本步新增填写或上传。试评、预检、冻结等按钮沿用前序材料，空参数不代表没有业务数据。下表分别展示本步输入、前序文件与后续报告依据；未单独留存的中间结果明确标注，后续报告不冒充该步骤的即时结果。</p>{steptables}<p>{filelink(f'walkthrough-docs/{sid}-operations.json','下载结构化操作表 JSON')}</p>
 <h3 id="{sid}-branches">缺口、整改、修订与取消分支</h3><p>明确终态可以是质量 BLOCK 且业务退回整改。未决副作用、复位或费用仍需对账；不能为了显示完成而改成 PASS。下图是分支操作定义，是否已走查以表格证据为准。</p>{detail('展开分支逐操作流程图','<div class="flow-svg">'+bsvg+'</div><p>'+filelink(f'walkthrough-docs/{sid}-branches.svg','下载 SVG')+' · '+filelink(f'walkthrough-docs/{sid}-branches.mmd','下载 Mermaid')+'</p>')}{table(['步骤','分支','操作','预期 / 终态','本轮证据边界'],branchrows)}{extra_operations_html}
 <h3 id="{sid}-evidence">实际证据、终态与限制</h3>{trace}
 {detail('本地检查断言与指标：独立命名空间', '<p class="notice">LOCAL/ 前缀是本文档给本地断言增加的限定名；原始报告编号不改写。尤其 LOCAL/pet/PET-01 不等于官方 PET-01，不能以四条本地断言宣称覆盖十六条宠物案例。</p>'+table(['本地断言 ID','检查项','指标','冻结参考','复核'],checkrows),sid=='pet')}
 <p class="source-note">需求依据：{'; '.join(ref(x) for x in rsc['source'])}。研究映射编号 {esc(rsc['id'])} 为文档组织 ID，不是新增官方 PRD 编号。</p>
 </section>'''
 scene_html.append(htmlpart)
 summary.append({'id':sid,'title':s['title'],'status':state,'uiClosed':closed,'terminalRecordExists':terminal_record_exists,'logValidation':log_validation,'invalidRowCount':invalid_row_count,'recordedOperations':len(rawops),'additionalBranchOperations':sum(len(x) for x in branch_logs.values()),'quality':sm.get('verdict'),'businessAcceptance':acceptance.get('status'),'terminalFields':terminal_fields,'actualRecord':latest,'evidenceFiles':evidence,'videoExists':video_valid,'screenshotCount':len(shots),'realServiceAcceptance':'NOT_VERIFIED','files':source_hashes})

# Keep all official identifiers and record their true verification boundary.
byid={s['id']:s for s in summary}
def links(ids):
 return ' · '.join(f'<a href="?scene={reverse[x]}">{esc(byid[reverse[x]]["title"])}</a>' for x in ids if x in reverse) or '跨场景 / 专项'
def coverage_status(ids):
 sceneids=[reverse[x] for x in ids if x in reverse]
 n=sum(byid[x]['uiClosed'] for x in sceneids)
 return f'关联演示 {n}/{len(sceneids)} 已记录闭环；正式条款未验收' if sceneids else '横切专项未做完整真实验收'
acrows=[]
for ac in req['mainAcceptance']:
 acrows.append([esc(ac['id']),esc(' / '.join(ac['cells'][1:])),links(ac['scenarioIds']),esc(coverage_status(ac['scenarioIds']))+'<small>'+esc('；'.join(ac.get('notes',[])))+'</small>',pill('真实验收未完成','warn')+'<small>'+ref(ac['source'])+'</small>'])
def detailed_rows(key):
 rows=[]
 for item in req[key]:
  linked=[s['id'] for s in req['proposedBusinessScenarios'] if item['id'] in s['detailedAcceptance']]
  if key=='detailedDET':
   related=[]
   for u in req['detailedUAT']:
    if item['id'] in str(u.get('mappedDET',[])):related.append(u['id'])
   for s in req['proposedBusinessScenarios']:
    if set(related)&set(s['detailedAcceptance']) and s['id'] not in linked:linked.append(s['id'])
  rows.append([esc(item['id']),esc(' / '.join(item['cells'][1:])),links(linked),esc(coverage_status(linked)),pill('未逐项真实验收','warn')+'<small>'+ref(item['source'])+'</small>'])
 return rows
petrows=[]
for item in req['detailedPET']:
 relation='本地“拒绝后无违规尝试”可提供拒绝反例的合成字段演示，尚非完整真实案例。' if item['id']=='PET-03' else '本轮本地断言不构成此官方案例通过；需按原案独立执行。'
 petrows.append([esc(item['id']),esc(' / '.join(item['cells'][1:])),esc(relation),pill('正式案例未验收','warn')+'<small>'+ref(item['source'])+'</small>'])
dependencies=table(['依赖 / 待决','仍需交付 / 冻结','状态与来源'],[[esc(x['id']),esc(x['need']),pill('未验证 / 待关闭','warn')+'<small>'+ref(x['source'])+'</small>'] for x in req['unresolvedDependencies']])
closed_count=sum(s['uiClosed'] for s in summary);total_ops=sum(s['recordedOperations'] for s in summary);video_count=sum(s['videoExists'] for s in summary)
results_table=table(['场景','UI 操作 / 闭环','质量 / 业务','媒体','真实验收'],[[f'<a href="?scene={s["id"]}">{esc(s["title"])}</a>',pill(s['status'],'good' if s['uiClosed'] else 'warn')+f'<small>{s["recordedOperations"]} 次实际操作</small>',esc(s.get('quality') or '快照未提供')+' / '+esc(s.get('businessAcceptance') or '未提供'),'逐步视频已生成' if s['videoExists'] else '视频尚未生成',pill('未验证','warn')] for s in summary])
readme='''# 场景走查文档生成说明\n\n运行 `python scripts/build-walkthrough-document.py`。可用 `--evidence-dir` 和 `--requirements` 指定证据与研究映射。\n\n生成器只读取现存的 manifest、操作日志、结果、报告与媒体；没有结果不得显示已通过，没有 MP4 不显示播放器。浏览器操作记录用于证明动作发生，不能自动证明每项预期或真实模型能力。\n\n媒体是本次实际页面截图合成的逐步演示，非连续录屏。每次录制完成后重新运行生成器更新页面。\n\n官方 AC/UAT/DET/PET 编号和本地断言必须分开；LOCAL/ 是文档显示限定名，不改写原始证据。\n'''
(DOCS/'README.md').write_text(readme)
(DOCS/'requirements-map.json').write_text(js(req))
copy_evidence(EVIDENCE/'browser-results-v17.json')
front=f'''<section id="overview" class="panel-view"><div class="scene-heading"><div><span class="eyebrow">ACCEPTANCE WALKTHROUGH / 2026.10.28</span><h2>从新建需求，到明确终态</h2><p>12 条业务链 · 逐操作证据 · 外部准备与接入 · 可下载场景 Demo</p></div>{pill('合成 / 离线证据回放','warn')}</div>
<div class="stats"><div><strong>{closed_count}<span>/12</span></strong><p>有闭环记录的业务链</p></div><div><strong>{total_ops}</strong><p>有日志的页面操作</p></div><div><strong>{video_count}<span>/12</span></strong><p>已生成逐步演示视频</p></div><div><strong>0</strong><p>本轮真实模型 / 设备验收</p></div></div>
<div class="notice"><strong>本轮能证明什么：</strong>真实页面操作、文件内容导入与摘要、角色切换、冻结、合成规则评分、业务验收及清理费用终态。模型输出和业务事件为拟真合成；本机 HTTP 仅验证模拟契约。真实账号鉴权、训练/推理、车辆和外部系统仍未验收。</div>
<p>“走通”是每个运行都有可解释的终态：PASS 可接受，BLOCK 可退回整改，取消需查询、复位与结算。必要证据或人工复核缺失时保留 INCONCLUSIVE，不把未知改为通过。</p>
<div class="downloads">{assetlink('walkthrough-assets.zip','下载完整准备包 ZIP')} · {filelink('walkthrough-docs/requirements-map.json','下载需求覆盖映射 JSON')} · {filelink('walkthrough-docs/evidence/browser-results-v17.json','下载实际浏览器结果')} · <button type="button" onclick="window.print()">打印 / 另存 PDF</button></div>
<h3>业务链与本轮证据状态</h3>{results_table}
<h3>需求基线与验收边界</h3><p>{esc(req['baseline']['mainVersion'])}。{esc(req['baseline']['retrievalBoundary'])}验收规格全文文字已读取；图示附件没有在研究子任务中核验。正式门槛、对象清单及接口须批准后再执行生产验收。</p>
{detail('主 PRD · AC-01—20 覆盖 / 阻塞矩阵',table(['条款','原文要求','关联业务链','本轮范围','真实状态 / 来源'],acrows),True)}
{detail('详细规格 · UAT-01—21 覆盖 / 阻塞矩阵',table(['条款','原文要求','关联业务链','本轮范围','真实状态 / 来源'],detailed_rows('detailedUAT')))}
{detail('检测能力 · DET-U01—15 覆盖 / 阻塞矩阵',table(['条款','原文要求','关联业务链','本轮范围','真实状态 / 来源'],detailed_rows('detailedDET')))}
{detail('官方宠物 PET-01—16 与本地断言的边界','<p class="notice">官方 PET-01 是有效事件、驻车、用户同意且终态正常；原始本地 PET-01 是拒绝后无违规尝试。二者同号不同义。本文统一显示 LOCAL/pet/PET-xx，官方矩阵保持原编号；不能将四条局部断言当成十六个案例。</p>'+table(['官方案例','原文输入 / 判定','本轮关联边界','状态 / 来源'],petrows))}
{detail('真实依赖与文档待决',dependencies,True)}
<p class="source-note">验收依据：prd-acceptance.md:2546（合成 Demo 不替代真实能力）；2550（平台正确检出 BLOCK 可以通过检测能力）；2554（21 UAT 与 15 DET 保留不同粒度）；2574（原型与生产验收分开）。</p>
</section>'''
CSS='''
:root{--navy:#142b46;--ink:#1b314d;--muted:#64748b;--line:#dce4ee;--bg:#f3f6fa;--blue:#255ca4;--green:#23756a;--amber:#8a6325}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);background:var(--bg);font:15px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}a{color:var(--blue);text-decoration:none}a:hover{text-decoration:underline}button,select{font:inherit}button{border:1px solid var(--line);background:#fff;color:var(--ink);padding:7px 12px;border-radius:7px;cursor:pointer}button:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid #75a7ea;outline-offset:3px}.topbar{height:68px;background:var(--navy);color:#fff;display:flex;justify-content:space-between;align-items:center;padding:0 30px;position:sticky;top:0;z-index:20}.brand{font-size:18px;font-weight:700;letter-spacing:.02em}.brand small{font-size:11px;color:#b0c6e3;display:block;letter-spacing:.13em}.topbar a{color:#e9f1fc;font-size:13px}.shell{display:grid;grid-template-columns:260px minmax(0,1fr);max-width:1720px;margin:auto}.sidebar{position:sticky;top:68px;align-self:start;height:calc(100vh - 68px);overflow:auto;background:#eaf0f7;padding:26px 16px;border-right:1px solid var(--line)}.sidebar .label{font-size:11px;letter-spacing:.13em;color:#6a7e98;margin:0 12px 11px}.sidebar a{display:block;border-radius:8px;padding:10px 12px;color:#334d6d;font-size:13px;margin-bottom:4px;line-height:1.45}.sidebar a[aria-current=page]{background:var(--navy);color:white}.sidebar a small{display:block;color:inherit;opacity:.68;font-size:10px;margin-top:3px}main{min-width:0;padding:32px 36px 70px}.panel-view{display:none;background:#fff;padding:30px 32px;border:1px solid var(--line);border-radius:12px;box-shadow:0 5px 20px #17304d06}.panel-view.active{display:block}.scene-heading{display:flex;align-items:start;justify-content:space-between;gap:20px}.eyebrow{font-size:11px;font-weight:700;letter-spacing:.14em;color:#6c829e}h2{font-size:30px;letter-spacing:-.04em;line-height:1.3;margin:10px 0 12px}h3{font-size:21px;margin:38px 0 16px;padding-top:4px;scroll-margin-top:88px}p{margin:12px 0;color:#425975}.muted,.source-note{color:var(--muted);font-size:12px}.pill{display:inline-block;padding:3px 9px;border-radius:5px;background:#edf2f8;color:#4e6380;font-size:11px;font-weight:600;white-space:normal;line-height:1.5}.pill.good{background:#e7f4ee;color:#24695b}.pill.warn{background:#fff2dc;color:#86601e}.tag-row{display:flex;gap:7px;flex-wrap:wrap;margin:13px 0 20px}.notice{background:#eef3f9;border-left:3px solid #6885aa;border-radius:4px;padding:14px 17px;margin:18px 0;font-size:13px;color:#3f5572}.notice.good{background:#edf7f1;border-color:#609782}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:24px 0}.stats>div{border:1px solid var(--line);border-radius:8px;padding:18px;background:#f8fafd}.stats strong{font-size:32px;font-weight:650}.stats strong span{font-size:17px;color:#97a7bc}.stats p{font-size:12px;margin:5px 0 0}.table-scroll{width:100%;overflow:auto;border:1px solid var(--line);border-radius:7px;margin:16px 0}table{width:100%;border-collapse:collapse;font-size:12px;line-height:1.65}th{padding:12px 13px;background:#edf2f8;color:#4b6484;text-align:left;font-weight:650;vertical-align:top;border-bottom:1px solid #cfdae8}td{padding:13px;border-bottom:1px solid #e6ecf3;vertical-align:top;min-width:105px;overflow-wrap:anywhere}tr:last-child td{border-bottom:0}td small{display:block;font-size:10px;color:#7b8b9f;margin-top:6px}tr:target,td:has(.anchor:target){background:#fff5dd}.operations{min-width:960px}.operations td:nth-child(1){min-width:104px}.operations td:nth-child(3){min-width:160px}.operations td:nth-child(4){min-width:210px}.operations td:nth-child(5){min-width:210px}.operations td:nth-child(6){min-width:140px}details{border:1px solid var(--line);border-radius:8px;margin:14px 0;background:#fff}summary{cursor:pointer;padding:14px 17px;font-weight:600;font-size:13px;background:#f8fafd;border-radius:8px;color:#365172}details[open]>summary{border-bottom:1px solid var(--line);border-radius:8px 8px 0 0}.detail-body{padding:14px 16px}.detail-body>p:first-child{margin-top:0}td details{margin:0;min-width:180px}td summary{padding:7px;font-size:11px}.code,code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.code{word-break:break-all}pre{overflow:auto;background:#11263e;color:#dbe8f7;border-radius:7px;padding:15px;font-size:11px;line-height:1.6;margin:12px 0;white-space:pre-wrap;overflow-wrap:anywhere;max-height:520px}.digest{font-size:10px;word-break:break-all}.downloads{font-size:13px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}.jump-nav{display:flex;flex-wrap:wrap;gap:16px;border-bottom:1px solid var(--line);padding:12px 0;font-size:12px}.flow-svg{max-width:960px;margin:auto}.flow-svg svg{display:block;width:100%;height:auto}.anchor{display:block;scroll-margin-top:105px}.shot-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.shot-grid figure{margin:0}.shot-grid img,.terminal-shot{width:100%;border:1px solid var(--line);border-radius:7px}figcaption{font-size:11px;color:#73869d;margin:5px 0 14px}video{display:block;width:100%;max-height:650px;background:#12283f;border-radius:8px}.missing{color:#965830}.mobile-nav{display:none}.footer{margin-top:26px;font-size:11px;color:#7890ab}li{margin:8px 0}ol{padding-left:24px}@media(max-width:1100px){.shell{grid-template-columns:220px minmax(0,1fr)}main{padding:22px 20px}.panel-view{padding:22px}.stats{grid-template-columns:repeat(2,1fr)}}@media(max-width:760px){.topbar{padding:0 16px;height:64px}.brand{font-size:15px}.shell{display:block}.sidebar{display:none}main{padding:16px 10px}.panel-view{padding:20px 15px;border-radius:8px}.mobile-nav{display:block;padding:14px 12px 0}.mobile-nav select{width:100%;padding:11px;border:1px solid var(--line);border-radius:7px;background:#fff}h2{font-size:25px}.scene-heading{display:block}.scene-heading>.pill{margin-bottom:10px}.stats{gap:8px}.stats>div{padding:12px}.stats strong{font-size:26px}.shot-grid{grid-template-columns:1fr}.detail-body{padding:10px}.flow-svg{min-width:560px}.detail-body:has(.flow-svg){overflow:auto}h3{font-size:19px}}@media print{.topbar,.sidebar,.mobile-nav,.jump-nav,button{display:none!important}.shell{display:block}main{padding:0}.panel-view{display:block!important;border:0;box-shadow:none;page-break-before:always;padding:0}details{break-inside:avoid}details>summary{background:#fff}.table-scroll{overflow:visible}.operations{min-width:0}video{display:none}.stats{grid-template-columns:repeat(4,1fr)}a{color:#183b6d}.flow-svg{max-width:700px}body{font-size:11px}h2{font-size:22px}}
'''
CSS+='\nh1{font-size:30px;letter-spacing:-.04em;line-height:1.3;margin:10px 0 12px}@media(max-width:760px){h1{font-size:25px}}@media print{.panel-view{display:none!important}.panel-view.active{display:block!important}}\n'
(DIST/'walkthrough.css').write_text(CSS)
nav='<a href="walkthrough.html" data-nav="overview">总览与覆盖矩阵<small>AC · UAT · DET · 真实依赖</small></a>'+''.join(f'<a href="?scene={s["id"]}" data-nav="{s["id"]}">{i+1:02}　{esc(s["title"])}<small>{esc(s["status"])} · {s["recordedOperations"]} 操作</small></a>' for i,s in enumerate(summary))
options='<option value="overview">总览与覆盖矩阵</option>'+''.join(f'<option value="{s["id"]}">{i+1:02} {esc(s["title"])}</option>' for i,s in enumerate(summary))
SCRIPT='''const params=new URLSearchParams(location.search);let current=params.get('scene')||'overview';if(!document.querySelector(`[data-scene="${CSS.escape(current)}"]`))current='overview';function activate(id,update){current=id;document.querySelectorAll('.panel-view').forEach(x=>x.classList.toggle('active',x.id===(id==='overview'?'overview':'scene-'+id)));document.querySelectorAll('[data-nav]').forEach(x=>{if(x.dataset.nav===id)x.setAttribute('aria-current','page');else x.removeAttribute('aria-current')});document.getElementById('scene-select').value=id;if(update){history.pushState({},'',id==='overview'?'walkthrough.html':'?scene='+encodeURIComponent(id));window.scrollTo(0,0)}}activate(current,false);document.querySelectorAll('[data-nav]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();activate(a.dataset.nav,true)}));document.getElementById('scene-select').addEventListener('change',e=>activate(e.target.value,true));window.addEventListener('popstate',()=>activate(new URLSearchParams(location.search).get('scene')||'overview',false));function revealHash(){const id=decodeURIComponent(location.hash.slice(1)),target=document.getElementById(id);if(!target)return;let p=target.parentElement;while(p){if(p.tagName==='DETAILS')p.open=true;p=p.parentElement}setTimeout(()=>target.scrollIntoView({block:'start'}),30)}window.addEventListener('hashchange',revealHash);document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(a)setTimeout(revealHash,0)});revealHash();window.addEventListener('beforeprint',()=>document.querySelectorAll('details').forEach(d=>{d.dataset.wasOpen=d.open?'1':'0';d.open=true}));window.addEventListener('afterprint',()=>document.querySelectorAll('details').forEach(d=>d.open=d.dataset.wasOpen==='1'));
'''
now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="AI评测平台12场景逐操作验收走查、外部准备、交互流程图与场景Demo。明确合成演示与真实验收边界。"><title>场景验收走查 · AI评测平台</title><link rel="stylesheet" href="walkthrough.css"></head><body><header class="topbar"><div class="brand">AI 评测平台<small>SCENARIO WALKTHROUGH</small></div><a href="index.html">返回交互站点 ↗</a></header><div class="mobile-nav"><label class="muted" for="scene-select">场景导航</label><select id="scene-select">{options}</select></div><div class="shell"><aside class="sidebar"><p class="label">验收场景 / SCENARIOS</p><nav aria-label="场景导航">{nav}</nav><p class="footer">PRD 基线 2026.10.27<br>本轮材料 2026.10.28<br>合成演示不代替真实验收</p></aside><main>{front}{''.join(scene_html)}<p class="footer">文档生成：{esc(now)} · 状态取自现存证据文件；新增记录或视频后重新运行生成器更新。{filelink('walkthrough-docs/README.md','生成说明')}</p></main></div><script>{SCRIPT}</script></body></html>'''
review=read(DOCS/'review-v17.json',{})
if review.get('findings'):
 findings='<h3>本轮 UI/UX 走查与修复</h3>'+table(['编号','发现的问题','修正后的行为','验证'],[[esc(f[k]) for k in ['id','issue','change','verification']] for f in review['findings']])+'<p>'+filelink('walkthrough-docs/review-v17.json','下载本轮审查记录')+'</p>'
 page=page.replace('<h3>需求基线与验收边界</h3>',findings+'<h3>需求基线与验收边界</h3>')
page=page.replace('<h2>','<h1>').replace('</h2>','</h1>').replace('打印 / 另存 PDF','打印当前页 / 另存 PDF')
(DIST/'walkthrough.html').write_text(page)
output={'generatedAt':now,'scope':'SYNTHETIC_UI_WALKTHROUGH_NOT_PRODUCTION_ACCEPTANCE','prdBaseline':req['baseline'],'counts':{'scenarios':len(summary),'uiClosed':closed_count,'recordedOperations':total_ops,'videos':video_count,'ac':len(req['mainAcceptance']),'uat':len(req['detailedUAT']),'det':len(req['detailedDET'])},'scenarios':summary,'missingFiles':missing,'requirementsMap':'walkthrough-docs/requirements-map.json'}
(DIST/'walkthrough.json').write_text(js(output))
# Check every generated local link rather than silently publishing broken downloads.
links_found=re.findall(r'(?:href|src)="([^"]+)"',page);broken=[]
for link in links_found:
 link=html.unescape(link)
 if link.startswith(('#','?','http:','https:','mailto:')):continue
 file=link.split('#')[0].split('?')[0]
 if file and not (DIST/file).exists():broken.append(link)
validation={'generatedAt':now,'scope':'Document artifact integrity only; not scenario or production acceptance','brokenLinks':sorted(set(broken)),'missingAssetFiles':missing,'counts':output['counts'],'operationLogs':{s['id']:s['logValidation']['status'] for s in summary},'status':'PASS' if not broken and not missing else 'FAIL'}
(DOCS/'build-validation.json').write_text(js(validation))
print(js(validation))
if broken or missing:raise SystemExit(1)
