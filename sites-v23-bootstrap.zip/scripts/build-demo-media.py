from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
import tarfile,json,subprocess,io,shutil,sys
root=Path(__file__).resolve().parents[1];base=Path('/workspace/scratch/lab-recordings');base.mkdir(exist_ok=True)
# Each image is an actual browser screenshot taken after the same action a user can perform.
durations=[6,6,10,8,10,10,10,8,8,10,7,6,9,12,6,9,7,10,5,6,5,8,5,9,6,10,12,6,5,10,7,5,10,10,5,8]
meta={}
for key in (sys.argv[1:] or ['office','pet','rag']):
 dest=base/key;dest.mkdir(exist_ok=True)
 with tarfile.open('/workspace/scratch/'+key+'-lab-frames.tar') as archive:
  archive.extractall(dest,filter='data')
 images=[Image.open(p).convert('RGB') for p in sorted(dest.glob('*.jpg'))]
 assert len(images)==36,(key,len(images))
 print(key,'sizes',sorted({im.size for im in images}),flush=True)
 width=max(im.width for im in images);height=max(im.height for im in images);width+=(width%2);height+=(height%2)
 images=[ImageOps.pad(im,(width,height),color='#f3f6fb') for im in images]
 encode=Path('/tmp/lab-media')/key;encode.mkdir(parents=True,exist_ok=True)
 for i,im in enumerate(images):
  buf=io.BytesIO();im.save(buf,format='PNG');target=encode/f'{i+1:03}.png';target.write_bytes(buf.getvalue())
  check=Image.open(target);check.load()
 with (encode/'concat.txt').open('w') as f:
  for i,d in enumerate(durations):f.write(f"file '{i+1:03}.png'\nduration {d}\n")
  f.write("file '036.png'\n")
 output=root/'dist/demos';output.mkdir(exist_ok=True)
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-xerror','-y','-f','concat','-safe','0','-i',str(encode/'concat.txt'),'-t',str(sum(durations)),'-vf','fps=12','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart','-an',str(encode/f'{key}-demo.mp4')],check=True)
 shutil.copyfile(encode/f'{key}-demo.mp4',output/f'{key}-demo.mp4')
 frames=[im.quantize(colors=256,method=Image.Quantize.MEDIANCUT) for im in images]
 frames[0].save(output/f'{key}-demo.gif',save_all=True,append_images=frames[1:],duration=[d*1000 for d in durations],loop=0,optimize=False,disposal=2)
 images[0].save(output/f'{key}-poster.jpg',quality=95)
 # Six major chapters follow the actual task steps, rather than separate canned scenes.
 chapters=[{'title':t,'start':sum(durations[:i])} for t,i in [('需求与数据准备',0),('评分标准',5),('调用接入',7),('用例与套件',11),('试评与发布',16),('执行与报告',24),('补证与专家复核',28)]]
 meta[key]={'frames':36,'seconds':sum(durations),'width':width,'height':height,'chapters':chapters}
 sheet=Image.new('RGB',(4*400,9*300),'#e9eef5');d=ImageDraw.Draw(sheet)
 for i,im in enumerate(images):
  thumbnail=ImageOps.contain(im,(400,275));x=i%4*400;y=i//4*300;sheet.paste(thumbnail,(x,y));d.text((x+8,y+278),f'{key} {i+1:02} / 36',fill='#12334c')
 sheet.save(base/f'{key}-contact.jpg',quality=90)
 print(key,'done',sum(durations),'seconds',flush=True)
(root/'dist/demo-media.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
