/* Runs the real shared UI controller in a Node DOM stub, not browser automation. */
const fs=require('node:fs'),path=require('node:path'),a=require('node:assert/strict');
const {harness}=require('../tests/helpers/prd-harness.cjs');
const E=require('../dist/prd-engine'),L=require('../dist/run-lifecycle'),W=require('../dist/walkthrough-contracts');
const root=path.resolve(__dirname,'..'),out=path.join(root,'dist/walkthrough-current');fs.mkdirSync(out,{recursive:true});
const manifest=JSON.parse(fs.readFileSync(path.join(root,'dist/walkthrough-assets/manifest.json')));
const startedAt=E.stamp(),results=[];
let assertions=0;
function check(ok,label){a.ok(ok,label);assertions++;}
function snap(x){const t=x.S.evalTasks.find(t=>t.id===x.S.evalTaskId),r=x.S.runs.find(r=>r.id===t?.prd?.runId);return {taskId:t?.id,revision:t?.revision,states:L.status(r),pilot:t?.prd?.pilot||null,preflight:t?.prd?.preflight||null,manifest:t?.prd?.manifest||null,issues:r?.issues||[],ledger:E.clone(x.ui.state().ledger)};}
async function record(x,rows,action,data,fn,actor){await fn();rows.push({n:rows.length+1,at:E.stamp(),actor:actor||x.S.role,action,data:data??null,observed:snap(x),verificationLayer:'NODE_SHARED_UI_CONTROLLER_NOT_BROWSER'});}
const act=(x,rows,name,key='',data=null)=>record(x,rows,name,data,()=>x.act(name,key));
const role=(x,rows,key)=>act(x,rows,'role',key,{role:key});
async function upload(x,rows,kind,relative){
 const names=Array.isArray(relative)?relative:[relative],files=names.map(n=>{const b=fs.readFileSync(path.join(root,'dist/walkthrough-assets',n));return {name:path.basename(n),size:b.length,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)}});
 await record(x,rows,'upload-'+kind,{files:names,contents:names.map(n=>fs.readFileSync(path.join(root,'dist/walkthrough-assets',n),'utf8'))},async()=>{for(const fn of x.events.change||[])await fn({target:{dataset:{walkUpload:kind},files}});});
 const t=x.S.evalTasks.find(t=>t.id===x.S.evalTaskId);check(kind==='source'?t.prd.sourceFiles.length>0:!!t.prd.files?.[kind],kind+' imported');
}
async function prepare(x,s,rows,mode='correct',cloned=false){
 await role(x,rows,'engineer');let t;
 if(!cloned){const seed={goal:'合成验证：'+s.title+'；检查正常自动收尾与独立状态',object:s.object,type:s.category};await record(x,rows,'create-requirement',seed,()=>{t=x.ui.createTask(null,true,seed)});await act(x,rows,'load-demo',s.id,{scene:s.id});}
 else t=x.S.evalTasks.at(-1);
 const fields={'p-name':s.title+' · '+mode,'p-object':s.object,'p-goal':t.goal,'p-version':s.version,'p-proof':s.proof,'p-budget':'10','p-department':s.fixture.department||'企业业务','p-type':s.category,'p-entry':'内置回放'};
 for(const [id,value] of Object.entries(fields))x.node(id).value=value;
 await act(x,rows,'save-task','',fields);
 await upload(x,rows,'input',s.inputFile);await upload(x,rows,'source',s.sourceFiles);await upload(x,rows,'connection',s.connectionFile);
 x.node('p-input-ready').checked=true;x.node('p-policy').checked=true;
 await act(x,rows,'data-ready','',{inputReviewed:true,demoStatisticsConfirmed:true});
 await upload(x,rows,'output',mode==='correct'?s.correctFile:s.failureFile);
 x.node('p-output').value=JSON.stringify(t.prd.outputs,null,2);
 await act(x,rows,'pilot');await act(x,rows,'preflight');check(t.prd.preflight.status==='READY',s.id+' preflight READY');
 await role(x,rows,'business');await act(x,rows,'business-confirm');await role(x,rows,'engineer');await act(x,rows,'freeze');await act(x,rows,'start');return t;
}
async function finish(x,rows,decision){
 await record(x,rows,'automatic-completion',null,()=>{while(x.timers.length)x.timers.shift()();},'system');
 const r=x.S.runs[0];check(r.state==='COMPLETED'&&r.settlement==='RECONCILED'&&r.environment==='RESET','automatic completion');
 check(r.issues.length===0,'normal path no operations todo');
 if(r.prdSnapshots.at(-1).summary.pending){await role(x,rows,'quality');await act(x,rows,'review-complete',r.id);}
 const quality=E.clone(r.prdSnapshots);
 await role(x,rows,'business');x.node('p-acceptance').value=decision;x.node('p-acceptance-reason').value=decision==='RETURNED'?'合成输出存在强制失败，退回修订；不覆盖质量结论。':'仅接受本次合成证据回放结果；不代表生产验收。';
 await act(x,rows,'acceptance-record',r.id,{decision,reason:x.node('p-acceptance-reason').value});
 check(L.status(r).businessComplete&&L.status(r).closed,'business completes without export');check(L.status(r).report==='NOT_EXPORTED','export optional');check(E.hash(r.prdSnapshots)===E.hash(quality),'quality unchanged');
 check(!rows.some(o=>['ops','maintainer','costManager'].includes(o.actor)),'no technical or financial person on normal flow');return r;
}
function branchResult(name,x,operations){const r=x.S.runs[0];return {name,operations,run:E.clone(r),states:L.status(r),ledger:E.clone(x.ui.state().ledger),verificationLayer:'NODE_SHARED_UI_CONTROLLER_NOT_BROWSER',browserStatus:'NOT_RUN'};}
(async()=>{
 for(const s of manifest.scenarios){
  const x=harness(),normal=[];await prepare(x,s,normal);const r=await finish(x,normal,'ACCEPTED');
  check(L.status(r).quality==='PASS',s.id+' correct quality');const main=branchResult('正常完成（未导出）',x,normal);
  const optional=[];await role(x,optional,'engineer');await act(x,optional,'export-report',r.id);check(x.ctx.downloads.length===1,'authorized export');
  fs.writeFileSync(path.join(out,s.id+'-optional-report.json'),x.ctx.downloads[0].value);
  await role(x,optional,'ops');await record(x,optional,'export-denied',{expected:'NO_REPORT_PERMISSION'},async()=>{await a.rejects(x.act('export-report',r.id),/报告访问拒绝/);assertions++;});
  const exports=branchResult('按需导出与越权拒绝',x,optional);
  const y=harness(),returned=[];const old=await prepare(y,s,returned,'failure');const oldRun=await finish(y,returned,'RETURNED');check(L.status(oldRun).quality==='BLOCK','failure retained after return');const before=E.clone(oldRun);const rejected=branchResult('退回整改',y,returned);
  const revised=[];await role(y,revised,'engineer');await act(y,revised,'clone',old.id,{fromTask:old.id});await prepare(y,s,revised,'correct',true);await finish(y,revised,'ACCEPTED');check(E.hash(oldRun)===E.hash(before),'old run unchanged');check(y.S.evalTasks.at(-1).id!==old.id,'new revision independent');const revision=branchResult('新修订重新验收',y,revised);
  const z=harness(),cancel=[];await prepare(z,s,cancel);const cr=z.S.runs[0];await act(z,cancel,'cancel',cr.id);check(cr.dispatchStopped&&cr.state==='RECONCILING','cancel stops dispatch first');await record(z,cancel,'automatic-query-cancel-cleanup',null,()=>{while(z.timers.length)z.timers.shift()();},'system');check(L.status(cr).closed&&cr.state==='CANCELLED'&&cr.prdSnapshots.length===0,'cancel verified without quality forgery');check(cr.issues.length===0,'normal cancel no operations todo');const cancelled=branchResult('取消自动核查',z,cancel);
  const exceptions=[];
  for(const [label,patch]of [['取消用量未知',{usage:[],usageComplete:false}],['取消复位失败',{resetVerified:false}],['取消副作用未知',{effectState:'UNKNOWN'}]]){
   const q=harness(),log=[];await prepare(q,s,log);const qr=q.S.runs[0];await act(q,log,'cancel',qr.id);q.timers.length=0;
   await record(q,log,'connector-exception-receipt',patch,()=>L.processReceipt(qr,q.ui.state().ledger,L.syntheticReceipt(qr,patch)),'system');
   check(!L.status(qr).closed&&q.ui.state().ledger.reservations[qr.id]>0,'unsafe cancellation holds budget');const unresolved=E.clone(qr);const quality=E.clone(qr.prdSnapshots);
   await role(q,log,'ops');await act(q,log,'reconcile',qr.id);q.node('p-reset-failure').checked=false;q.node('p-usage-missing').checked=false;q.node('p-effect-unknown').checked=false;await act(q,log,'reconcile-apply',qr.id);
   check(L.status(qr).closed,'technical recovery resumes automatic completion');check(E.hash(qr.prdSnapshots)===E.hash(quality),'recovery preserves quality');
   exceptions.push({...branchResult(label,q,log),beforeRecovery:unresolved});
  }
  const result={scene:s.id,title:s.title,at:E.stamp(),main,branches:[exports,rejected,revision,cancelled,...exceptions],status:'PASS',browserStatus:'NOT_RUN',scope:'SYNTHETIC_SHARED_UI_CONTROLLER_ONLY'};
  fs.writeFileSync(path.join(out,s.id+'-verification.json'),JSON.stringify(result,null,2));results.push({scene:s.id,title:s.title,status:'PASS',paths:8,operations:normal.length+result.branches.reduce((n,b)=>n+b.operations.length,0),browserStatus:'NOT_RUN',file:s.id+'-verification.json'});
 }
 const summary={baseline:L.VERSION,startedAt,finishedAt:E.stamp(),scope:'SYNTHETIC_SHARED_UI_CONTROLLER_ONLY',notProduction:true,scenarios:results,assertions,counts:{scenarios:results.length,paths:results.length*8,operations:results.reduce((n,s)=>n+s.operations,0)},materialsStatus:'NEW_LOGS_AND_STATE_RECORDS_GENERATED; browser and new video separate',status:'PASS'};
 fs.writeFileSync(path.join(out,'verification-summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
